google.maps.__gjsload__("controls", function (_) {
  var JJa,
    kL,
    KJa,
    LJa,
    mL,
    MJa,
    NJa,
    OJa,
    PJa,
    oL,
    RJa,
    pL,
    qL,
    rL,
    sL,
    TJa,
    SJa,
    VJa,
    tL,
    WJa,
    wL,
    XJa,
    YJa,
    ZJa,
    uL,
    yL,
    vL,
    xL,
    BL,
    aKa,
    $Ja,
    CL,
    DL,
    cKa,
    bKa,
    dKa,
    eKa,
    fKa,
    hKa,
    EL,
    iKa,
    gKa,
    FL,
    jKa,
    GL,
    IL,
    JL,
    mKa,
    nKa,
    oKa,
    KL,
    LL,
    ML,
    pKa,
    qKa,
    NL,
    rKa,
    uKa,
    sKa,
    vKa,
    PL,
    yKa,
    xKa,
    zKa,
    RL,
    BKa,
    AKa,
    CKa,
    DKa,
    HKa,
    GKa,
    IKa,
    SL,
    JKa,
    KKa,
    LKa,
    TL,
    MKa,
    NKa,
    OKa,
    PKa,
    QKa,
    RKa,
    UL,
    SKa,
    WL,
    UKa,
    VKa,
    WKa,
    XKa,
    YKa,
    ZKa,
    TKa,
    $Ka,
    aLa,
    bLa,
    cLa,
    dLa,
    fLa,
    YL,
    hLa,
    jLa,
    kLa,
    lLa,
    mLa,
    nLa,
    pLa,
    qLa,
    oLa,
    rLa,
    sLa,
    tLa,
    vLa,
    wLa,
    zLa,
    ALa,
    ZL,
    BLa,
    uLa,
    xLa,
    GLa,
    ELa,
    FLa,
    DLa,
    $L,
    HLa,
    ILa,
    JLa,
    KLa,
    NLa,
    PLa,
    RLa,
    TLa,
    VLa,
    WLa,
    YLa,
    $La,
    bMa,
    dMa,
    sMa,
    yMa,
    cMa,
    hMa,
    gMa,
    fMa,
    iMa,
    cM,
    jMa,
    zMa,
    aM,
    dM,
    qMa,
    MLa,
    eMa,
    tMa,
    lMa,
    nMa,
    oMa,
    pMa,
    rMa,
    bM,
    mMa,
    GMa,
    KMa,
    LMa,
    eM,
    MMa,
    NMa,
    fM,
    OMa,
    RMa,
    QMa,
    SMa,
    QJa,
    UJa;
  JJa = function (a, b, c) {
    _.Mq(a, b, "animate", c);
  };
  kL = function (a) {
    a.style.textAlign = _.Ly.Fj() ? "right" : "left";
  };
  KJa = function (a, b, c) {
    var d = a.length;
    const e = typeof a === "string" ? a.split("") : a;
    for (--d; d >= 0; --d) d in e && b.call(c, e[d], d, a);
  };
  LJa = function (a) {
    return String(a).replace(/\-([a-z])/g, function (b, c) {
      return c.toUpperCase();
    });
  };
  _.lL = function (a, b) {
    a.classList
      ? a.classList.remove(b)
      : _.wja(a, b) &&
        _.vja(
          a,
          Array.prototype.filter
            .call(
              a.classList ? a.classList : _.Bs(a).match(/\S+/g) || [],
              function (c) {
                return c != b;
              }
            )
            .join(" ")
        );
  };
  mL = function (a) {
    return a ? a.style.display !== "none" : !1;
  };
  _.nL = function (a) {
    _.lL(a, "gmnoscreen");
    _.Cs(a, "gmnoprint");
  };
  MJa = function (a, b) {
    a.style.borderTopLeftRadius = b;
    a.style.borderTopRightRadius = b;
  };
  NJa = function (a, b) {
    a.style.borderBottomLeftRadius = b;
    a.style.borderBottomRightRadius = b;
  };
  OJa = function (a) {
    var b = _.ds(2);
    a.style.borderBottomLeftRadius = b;
    a.style.borderTopLeftRadius = b;
  };
  PJa = function (a) {
    var b = _.ds(2);
    a.style.borderBottomRightRadius = b;
    a.style.borderTopRightRadius = b;
  };
  oL = function (a, b) {
    b = b || {};
    var c = a.style;
    c.color = "black";
    c.fontFamily = "Roboto,Arial,sans-serif";
    _.Ls(a);
    _.Ks(a);
    b.title && a.setAttribute("title", b.title);
    c = _.Ns() ? 1.38 : 1;
    a = a.style;
    a.fontSize = _.ds(b.fontSize || 11);
    a.backgroundColor = b.Ai ? "#444" : "#fff";
    const d = [];
    for (let e = 0, f = _.rj(b.padding); e < f; ++e)
      d.push(_.ds(c * b.padding[e]));
    a.padding = d.join(" ");
    b.width && (a.width = _.ds(c * b.width));
  };
  RJa = function (a, b) {
    let c = QJa[b];
    if (!c) {
      var d = LJa(b);
      c = d;
      a.style[d] === void 0 &&
        ((d = _.BE() + _.NAa(d)), a.style[d] !== void 0 && (c = d));
      QJa[b] = c;
    }
    return c;
  };
  pL = function (a, b, c) {
    if (typeof b === "string") (b = RJa(a, b)) && (a.style[b] = c);
    else
      for (const e in b) {
        c = a;
        var d = b[e];
        const f = RJa(c, e);
        f && (c.style[f] = d);
      }
  };
  qL = function (a, b, c) {
    let d;
    b instanceof _.$r ? ((d = b.x), (b = b.y)) : ((d = b), (b = c));
    a.style.left = _.CE(d, !1);
    a.style.top = _.CE(b, !1);
  };
  rL = function (a) {
    return a > 40 ? a / 2 - 2 : a < 28 ? a - 10 : 18;
  };
  sL = function (a, b) {
    _.dHa(a, b);
    b = a.items[b];
    return {
      url: _.Yn(a.rl.url, !a.rl.Zu, a.rl.Zu),
      size: a.Rl,
      scaledSize: a.rl.size,
      origin: b.pn,
      anchor: a.anchor,
    };
  };
  TJa = function (a) {
    a = SJa(a, "hybrid", "satellite", "labels", "Nh\u00e3n");
    a.set("enabled", !0);
    return a;
  };
  SJa = function (a, b, c, d, e, f) {
    const g = a.Ig.get(b);
    e = new UJa(e || g.name, g.alt, d, !0, !1, f);
    a.mapping[b] = { mapTypeId: c, Cv: d, value: !0 };
    a.mapping[c] = { mapTypeId: c, Cv: d, value: !1 };
    return e;
  };
  VJa = function (a, b, c) {
    const d = _.eu(a === 0 ? "Ph\u00f3ng to" : "Thu nh\u1ecf");
    d.setAttribute("class", "gm-control-active");
    d.style.overflow = "hidden";
    tL(d, a, b, c);
    return d;
  };
  tL = function (a, b, c, d) {
    a.innerText = "";
    b =
      b === 0
        ? d === 2
          ? [
              _.fy["zoom_in_normal_dark.svg"],
              _.fy["zoom_in_hover_dark.svg"],
              _.fy["zoom_in_active_dark.svg"],
              _.fy["zoom_in_disable_dark.svg"],
            ]
          : [
              _.fy["zoom_in_normal.svg"],
              _.fy["zoom_in_hover.svg"],
              _.fy["zoom_in_active.svg"],
              _.fy["zoom_in_disable.svg"],
            ]
        : d === 2
        ? [
            _.fy["zoom_out_normal_dark.svg"],
            _.fy["zoom_out_hover_dark.svg"],
            _.fy["zoom_out_active_dark.svg"],
            _.fy["zoom_out_disable_dark.svg"],
          ]
        : [
            _.fy["zoom_out_normal.svg"],
            _.fy["zoom_out_hover.svg"],
            _.fy["zoom_out_active.svg"],
            _.fy["zoom_out_disable.svg"],
          ];
    for (const e of b)
      (b = document.createElement("img")),
        (b.style.width = b.style.height = `${rL(c)}px`),
        (b.src = e),
        (b.alt = ""),
        a.appendChild(b);
  };
  WJa = function (a, b, c, d) {
    const e = document.activeElement === c || document.activeElement === d;
    if (typeof a === "number" && b) {
      const f = a >= b.max;
      c.style.cursor = f ? "default" : "pointer";
      e && !c.disabled && f && d.focus();
      c.disabled = f;
      a = a <= b.min;
      d.style.cursor = a ? "default" : "pointer";
      e && !d.disabled && a && c.focus();
      d.disabled = a;
    }
  };
  wL = function (a, b) {
    switch (b) {
      case "Down":
        var c = "Di chuy\u1ec3n xu\u1ed1ng";
        break;
      case "Left":
        c = "Di chuy\u1ec3n sang tr\u00e1i";
        break;
      case "Right":
        c = "Di chuy\u1ec3n sang ph\u1ea3i";
        break;
      default:
        c = "Di chuy\u1ec3n l\u00ean";
    }
    c = _.eu(c);
    uL(a, c);
    c.style.position = "absolute";
    switch (b) {
      case "Down":
        vL(a, c, "Down");
        c.style.bottom = "0";
        c.style.left = "50%";
        c.style.transform = "translateX(-50%)";
        break;
      case "Left":
        vL(a, c, "Left");
        c.style.bottom = "50%";
        c.style.left = "0";
        c.style.transform = "translateY(50%)";
        break;
      case "Right":
        vL(a, c, "Right");
        c.style.bottom = "50%";
        c.style.right = "0";
        c.style.transform = "translateY(50%)";
        break;
      default:
        vL(a, c, "Up"),
          (c.style.top = "0"),
          (c.style.left = "50%"),
          (c.style.transform = "translateX(-50%)");
    }
    c.addEventListener("click", (d) => {
      switch (b) {
        case "Down":
          _.Ek(a, "panbyfraction", 0, 0.5);
          break;
        case "Left":
          _.Ek(a, "panbyfraction", -0.5, 0);
          break;
        case "Right":
          _.Ek(a, "panbyfraction", 0.5, 0);
          break;
        default:
          _.Ek(a, "panbyfraction", 0, -0.5);
      }
      _.M(window, _.uE(d) ? 226023 : 226022);
    });
    return c;
  };
  XJa = function (a, b) {
    const c = VJa(b, a.controlSize, a.Ig);
    uL(a, c);
    c.style.position = "absolute";
    b === 0 ? (c.style.top = "0") : (c.style.bottom = "0");
    a.av ? (c.style.left = "0") : (c.style.right = "0");
    c.addEventListener("click", (d) => {
      _.Ek(a, "zoomMap", b);
      _.M(window, _.uE(d) ? 226021 : 226020);
    });
    return c;
  };
  YJa = function (a) {
    a.Eg.id = _.co();
    a.Eg.style.listStyle = "none";
    a.Eg.style.padding = "0";
    a.Eg.style.display = "none";
    a.Eg.style.position = "absolute";
    a.Eg.style.zIndex = "999999";
    var b = a.controlSize >> 2;
    a.Eg.style.margin = `${b}px`;
    a.Eg.style.height = a.Eg.style.width = `${a.controlSize * 3 + b * 2}px`;
    b = (c) => {
      const d = document.createElement("li");
      d.appendChild(c);
      a.Eg.appendChild(d);
    };
    b(a.Og);
    b(a.Kg);
    b(a.Lg);
    b(a.Jg);
    b(a.Pg);
    b(a.Ug);
  };
  ZJa = function (a) {
    a.Hg.addEventListener("click", (b) => {
      xL(a);
      _.M(window, _.uE(b) ? 226001 : 226e3);
    });
    a.addEventListener("focusout", (b) => {
      b = a.contains(b.relatedTarget);
      a.Fg && !b && xL(a);
    });
    a.Eg.addEventListener("keydown", (b) => {
      b.key === "Escape" && a.Fg && (xL(a), a.Hg.focus());
    });
  };
  uL = function (a, b) {
    b.classList.add("gm-control-active");
    b.style.width = `${a.controlSize}px`;
    b.style.height = `${a.controlSize}px`;
    b.style.borderRadius = "50%";
    b.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
    const c = Math.round(a.controlSize * 0.7);
    b.style.backgroundColor = "#fff";
    b.style.backgroundRepeat = "no-repeat";
    b.style.backgroundSize = `${c}px`;
    b.style.backgroundPosition = `${(a.controlSize - c) / 2}px`;
  };
  yL = function (a, b, c) {
    c.innerText = "";
    for (const d of b)
      (b = document.createElement("img")),
        (b.style.width = b.style.height =
          `${Math.round(a.controlSize * 0.7)}px`),
        (b.src = d),
        (b.alt = ""),
        c.appendChild(b);
  };
  vL = function (a, b, c) {
    b.innerText = "";
    const d = a.Ig === 2 ? "_dark" : "";
    yL(
      a,
      [
        _.fy[`camera_move_${c.toLowerCase()}${d}.svg`],
        _.fy[`camera_move_${c.toLowerCase()}_hover${d}.svg`],
        _.fy[`camera_move_${c.toLowerCase()}_active${d}.svg`],
        _.fy[`camera_move_${c.toLowerCase()}_disable${d}.svg`],
      ],
      b
    );
  };
  xL = function (a) {
    a.Fg = !a.Fg;
    a.Hg.setAttribute("aria-expanded", a.Fg.toString());
    a.Eg.style.display = a.Fg ? "" : "none";
  };
  BL = function (a) {
    a = _.Ba(a);
    delete zL[a];
    _.sf(zL) && AL && AL.stop();
  };
  aKa = function () {
    AL ||
      (AL = new _.Nm(function () {
        $Ja();
      }, 20));
    const a = AL;
    a.isActive() || a.start();
  };
  $Ja = function () {
    var a = _.Ea();
    _.rf(zL, function (b) {
      bKa(b, a);
    });
    _.sf(zL) || aKa();
  };
  CL = function () {
    _.mg.call(this);
    this.Eg = 0;
    this.endTime = this.startTime = null;
  };
  DL = function (a, b, c, d) {
    CL.call(this);
    if (!Array.isArray(a) || !Array.isArray(b))
      throw Error("Start and end parameters must be arrays");
    if (a.length != b.length)
      throw Error("Start and end points must be the same length");
    this.Fg = a;
    this.Ig = b;
    this.duration = c;
    this.Hg = d;
    this.coords = [];
    this.progress = 0;
  };
  cKa = function (a) {
    if (a.Eg == 0) (a.progress = 0), (a.coords = a.Fg);
    else if (a.Eg == 1) return;
    BL(a);
    const b = _.Ea();
    a.startTime = b;
    a.Eg == -1 && (a.startTime -= a.duration * a.progress);
    a.endTime = a.startTime + a.duration;
    a.progress || a.Bn("begin");
    a.Bn("play");
    a.Eg == -1 && a.Bn("resume");
    a.Eg = 1;
    const c = _.Ba(a);
    c in zL || (zL[c] = a);
    aKa();
    bKa(a, b);
  };
  bKa = function (a, b) {
    b < a.startTime &&
      ((a.endTime = b + a.endTime - a.startTime), (a.startTime = b));
    a.progress = (b - a.startTime) / (a.endTime - a.startTime);
    a.progress > 1 && (a.progress = 1);
    dKa(a, a.progress);
    a.progress == 1
      ? ((a.Eg = 0), BL(a), a.Bn("finish"), a.Bn("end"))
      : a.Eg == 1 && a.Bn("animate");
  };
  dKa = function (a, b) {
    typeof a.Hg === "function" && (b = a.Hg(b));
    a.coords = Array(a.Fg.length);
    for (let c = 0; c < a.Fg.length; c++)
      a.coords[c] = (a.Ig[c] - a.Fg[c]) * b + a.Fg[c];
  };
  eKa = function (a, b) {
    _.Xf.call(this, a);
    this.coords = b.coords;
    this.x = b.coords[0];
    this.y = b.coords[1];
    this.z = b.coords[2];
    this.duration = b.duration;
    this.progress = b.progress;
    this.state = b.Eg;
  };
  fKa = function (a) {
    return 3 * a * a - 2 * a * a * a;
  };
  hKa = function (a, b, c) {
    const d = a.get("pov");
    if (d) {
      var e = _.Yr(d.heading, 360);
      a.startAnimation(
        e,
        c ? Math.floor((e + 100) / 90) * 90 : Math.ceil((e - 100) / 90) * 90,
        d.pitch,
        d.pitch
      );
      gKa(b);
    }
  };
  EL = function (a) {
    const b = a.get("mapSize"),
      c = a.get("panControl"),
      d = !!a.get("disableDefaultUI");
    a.layout.mh.style.visibility =
      c || (c === void 0 && !d && b && b.width >= 200 && b.height >= 200)
        ? ""
        : "hidden";
    _.Ek(a.layout.mh, "resize");
  };
  iKa = function (a, b, c) {
    a.Eg = !0;
    const d = a.get("pov");
    d &&
      (a.set("pov", { heading: c.coords[0], pitch: c.coords[1], zoom: d.zoom }),
      (a.Eg = !1),
      b && (a.animation = null));
  };
  gKa = function (a) {
    const b = _.uE(a) ? "Cmcmi" : "Cmcki";
    _.M(window, _.uE(a) ? 171336 : 171335);
    _.pl(window, b);
  };
  FL = function (a, b, c, d) {
    a.innerText = "";
    b = b
      ? d === 2
        ? [
            _.fy["fullscreen_exit_normal_dark.svg"],
            _.fy["fullscreen_exit_hover_dark.svg"],
            _.fy["fullscreen_exit_active_dark.svg"],
          ]
        : [
            _.fy["fullscreen_exit_normal.svg"],
            _.fy["fullscreen_exit_hover.svg"],
            _.fy["fullscreen_exit_active.svg"],
          ]
      : d === 2
      ? [
          _.fy["fullscreen_enter_normal_dark.svg"],
          _.fy["fullscreen_enter_hover_dark.svg"],
          _.fy["fullscreen_enter_active_dark.svg"],
        ]
      : [
          _.fy["fullscreen_enter_normal.svg"],
          _.fy["fullscreen_enter_hover.svg"],
          _.fy["fullscreen_enter_active.svg"],
        ];
    for (const e of b)
      (b = document.createElement("img")),
        (b.style.width = b.style.height = _.ds(rL(c))),
        (b.src = e),
        (b.alt = ""),
        a.appendChild(b);
  };
  jKa = function (a) {
    const b = a.Jg;
    for (const c of b) _.uk(c);
    a.Jg.length = 0;
  };
  GL = function (a, b) {
    a.Eg.style.backgroundColor = kKa[b].backgroundColor;
    a.Fg && ((a.Kg = b), FL(a.Eg, a.Il.get(), a.Ig, b));
  };
  _.HL = function (a, b = document.head, c = !1) {
    _.Ls(a);
    _.Ks(a);
    _.yq(lKa, b);
    _.Cs(a, "gm-style-cc");
    a.style.position = "relative";
    b = _.Is("div", a);
    _.Is("div", b).style.width = _.ds(1);
    const d = (a.qj = _.Is("div", b));
    d.style.backgroundColor = c ? "#000" : "#f5f5f5";
    d.style.width = "auto";
    d.style.height = "100%";
    d.style.marginLeft = _.ds(1);
    _.sE(b, 0.7);
    b.style.width = "100%";
    b.style.height = "100%";
    _.Gs(b);
    b = a.Ng = _.Is("div", a);
    b.style.position = "relative";
    b.style.paddingLeft = b.style.paddingRight = _.ds(6);
    b.style.boxSizing = "border-box";
    b.style.fontFamily = "Roboto,Arial,sans-serif";
    b.style.fontSize = _.ds(10);
    b.style.color = c ? "#fff" : "#000000";
    b.style.whiteSpace = "nowrap";
    b.style.direction = "ltr";
    b.style.textAlign = "right";
    a.style.height = _.ds(14);
    a.style.lineHeight = _.ds(14);
    b.style.verticalAlign = "middle";
    b.style.display = "inline-block";
    return b;
  };
  IL = function (a) {
    a.qj &&
      ((a.qj.style.backgroundColor = "#000"), (a.Ng.style.color = "#fff"));
  };
  JL = async function (a) {
    _.Ek(a.Yg, "resize");
  };
  mKa = function (a) {
    const b = _.eu("Ph\u00edm t\u1eaft");
    a.Yg.appendChild(b);
    _.Js(b, 1000002);
    b.style.position = "absolute";
    b.style.backgroundColor = "transparent";
    b.style.border = "none";
    b.style.outlineOffset = "3px";
    _.mE(b, "click", a.Fg.Eg);
    return b;
  };
  nKa = function (a) {
    a.element.style.right = "0px";
    a.element.style.bottom = "0px";
    a.element.style.transform = "translateX(100%)";
  };
  oKa = function (a) {
    const {
        height: b,
        width: c,
        bottom: d,
        right: e,
      } = a.Fg.Eg.getBoundingClientRect(),
      { bottom: f, right: g } = a.Hg.getBoundingClientRect();
    a.element.style.transform = "";
    a.element.style.height = `${b}px`;
    a.element.style.width = `${c}px`;
    a.element.style.bottom = `${f - d}px`;
    a.element.style.right = `${g - e}px`;
  };
  KL = function (a, b) {
    if (!mL(a)) return 0;
    b = !b && _.gE(a.dataset.controlWidth);
    if (!_.xj(b) || isNaN(b)) b = a.offsetWidth;
    a = _.GG(a);
    b += _.gE(a.marginLeft) || 0;
    return (b += _.gE(a.marginRight) || 0);
  };
  LL = function (a, b) {
    if (!mL(a)) return 0;
    b = !b && _.gE(a.dataset.controlHeight);
    if (!_.xj(b) || isNaN(b)) b = a.offsetHeight;
    a = _.GG(a);
    b += _.gE(a.marginTop) || 0;
    return (b += _.gE(a.marginBottom) || 0);
  };
  ML = function (a, b) {
    let c = b;
    switch (b) {
      case 24:
        c = 11;
        break;
      case 23:
        c = 10;
        break;
      case 25:
        c = 12;
        break;
      case 19:
        c = 6;
        break;
      case 17:
        c = 4;
        break;
      case 18:
        c = 5;
        break;
      case 22:
        c = 9;
        break;
      case 21:
        c = 8;
        break;
      case 20:
        c = 7;
        break;
      case 15:
        c = 2;
        break;
      case 14:
        c = 1;
        break;
      case 16:
        c = 3;
        break;
      default:
        return c;
    }
    return pKa(a, c);
  };
  pKa = function (a, b) {
    if (!a.get("isRTL")) return b;
    switch (b) {
      case 10:
        return 12;
      case 12:
        return 10;
      case 6:
        return 9;
      case 4:
        return 8;
      case 5:
        return 7;
      case 9:
        return 6;
      case 8:
        return 4;
      case 7:
        return 5;
      case 1:
        return 3;
      case 3:
        return 1;
    }
    return b;
  };
  qKa = function (a, b) {
    const c = {
      element: b,
      height: 0,
      width: 0,
      fB: _.sk(b, "resize", () => void NL(a, c)),
    };
    return c;
  };
  NL = function (a, b) {
    b.width = _.gE(b.element.dataset.controlWidth);
    b.height = _.gE(b.element.dataset.controlHeight);
    b.width || (b.width = b.element.offsetWidth);
    b.height || (b.height = b.element.offsetHeight);
    let c = 0;
    for (const { element: h, width: k } of a.elements)
      mL(h) && h.style.visibility !== "hidden" && (c = Math.max(c, k));
    let d = 0,
      e = !1;
    const f = a.padding;
    a.Fg(a.elements, ({ element: h, height: k, width: m }) => {
      mL(h) &&
        h.style.visibility !== "hidden" &&
        (e ? (d += f) : (e = !0),
        (h.style.left = _.ds((c - m) / 2)),
        (h.style.top = _.ds(d)),
        (d += k));
    });
    b = c;
    const g = d;
    a.Yg.dataset.controlWidth = `${b}`;
    a.Yg.dataset.controlHeight = `${g}`;
    _.pE(a.Yg, !(!b && !g));
    _.Ek(a.Yg, "resize");
  };
  rKa = function (a, b) {
    var c =
      "B\u1ea1n \u0111ang s\u1eed d\u1ee5ng tr\u00ecnh duy\u1ec7t kh\u00f4ng \u0111\u01b0\u1ee3c API JavaScript cu\u0309a Google Maps h\u00f4\u0303 tr\u01a1\u0323. Vui l\u00f2ng c\u00e2n nh\u1eafc vi\u1ec7c thay \u0111\u1ed5i tr\u00ecnh duy\u1ec7t c\u1ee7a b\u1ea1n.";
    const d = document.createElement("div");
    d.className = "infomsg";
    a.appendChild(d);
    const e = d.style;
    e.background = "#F9EDBE";
    e.border = "1px solid #F0C36D";
    e.borderRadius = "2px";
    e.boxSizing = "border-box";
    e.boxShadow = "0 2px 4px rgba(0,0,0,0.2)";
    e.fontFamily = "Roboto,Arial,sans-serif";
    e.fontSize = "12px";
    e.fontWeight = "400";
    e.left = "10%";
    e.Eg = "2px";
    e.padding = "5px 14px";
    e.position = "absolute";
    e.textAlign = "center";
    e.top = "10px";
    e.webkitBorderRadius = "2px";
    e.width = "80%";
    e.zIndex = 24601;
    d.innerText = c;
    c = document.createElement("a");
    b &&
      (d.appendChild(document.createTextNode(" ")),
      d.appendChild(c),
      (c.innerText = "T\u00ecm hi\u1ec3u th\u00eam"),
      (c.href = b),
      (c.target = "_blank"));
    b = document.createElement("a");
    d.appendChild(document.createTextNode(" "));
    d.appendChild(b);
    b.innerText = "Lo\u1ea1i b\u1ecf";
    b.target = "_blank";
    c.style.paddingLeft = b.style.paddingLeft = "0.8em";
    c.style.boxSizing = b.style.boxSizing = "border-box";
    c.style.color = b.style.color = "black";
    c.style.cursor = b.style.cursor = "pointer";
    c.style.textDecoration = b.style.textDecoration = "underline";
    c.style.whiteSpace = b.style.whiteSpace = "nowrap";
    b.onclick = function () {
      a.removeChild(d);
    };
  };
  uKa = function (a, b, c, d) {
    function e() {
      const h = g.get("hasCustomStyles"),
        k = a.getMapTypeId(),
        m = d === 2;
      sKa(f, h || k === "satellite" || k === "hybrid" || m);
    }
    const f = new tKa(a, b, c),
      g = a.__gm;
    _.sk(g, "hascustomstyles_changed", e);
    _.sk(a, "maptypeid_changed", e);
    e();
    return f;
  };
  sKa = function (a, b) {
    _.LG(
      a.Mg,
      b ? _.fy["google_logo_white.svg"] : _.fy["google_logo_color.svg"]
    );
  };
  vKa = function (a) {
    a.Jg && a.Ig.get("passiveLogo")
      ? a.Fg.contains(a.Eg)
        ? a.Fg.replaceChild(a.Hg, a.Eg)
        : a.Fg.appendChild(a.Hg)
      : (a.Eg.appendChild(a.Hg), a.Fg.appendChild(a.Eg));
  };
  _.OL = function (a, b, c, d) {
    return new wKa(a, b, c, d);
  };
  PL = function (a, b) {
    let c = !!a.get("active") || a.Kg;
    a.get("enabled") == 0
      ? ((a.Fg.color = "gray"), (b = c = !1))
      : ((a.Fg.color = a.Ig
          ? c || b
            ? "#fff"
            : "#aaa"
          : c || b
          ? "#000"
          : "#565656"),
        a.Jg && a.Eg.setAttribute("aria-checked", c));
    a.Lg || (a.Fg.borderLeft = "0");
    _.xj(a.Hg) && (a.Fg.paddingLeft = _.ds(a.Hg));
    a.Fg.fontWeight = c ? "500" : "";
    a.Fg.backgroundColor = a.Ig
      ? b
        ? "#666"
        : "#444"
      : b
      ? "#ebebeb"
      : "#fff";
  };
  yKa = function (a, b, c) {
    _.Ck(a, "active_changed", () => {
      const d = !!a.get("active");
      a.Fg.style.display = d ? "" : "none";
      a.Hg.style.display = d ? "none" : "";
      a.Eg.setAttribute("aria-checked", d ? "true" : "false");
    });
    _.yk(a.Eg, "mouseover", () => {
      xKa(a, !0);
    });
    _.yk(a.Eg, "mouseout", () => {
      xKa(a, !1);
    });
    b = new QL(a.Eg, b, c);
    b.bindTo("value", a);
    b.bindTo("display", a);
    a.bindTo("active", b);
  };
  xKa = function (a, b) {
    a.Eg.style.backgroundColor = a.Ai
      ? b
        ? "#666"
        : "#444"
      : b
      ? "#ebebeb"
      : "#fff";
  };
  zKa = function (a, b, c) {
    function d() {
      function e(f) {
        for (const g of f) if (g.get("display") !== !1) return !0;
        return !1;
      }
      a.set("display", e(b) && e(c));
    }
    for (const e of b.concat(c)) _.sk(e, "display_changed", d);
  };
  RL = function (a) {
    return a.Kg
      ? a.shadowRoot.activeElement || document.activeElement
      : document.activeElement;
  };
  BKa = function (a, b) {
    if (b.key === "Escape" || b.key === "Esc") a.set("active", !1);
    else {
      var c = a.Hg.filter((e) => e.get("display") !== !1),
        d = a.Fg ? c.indexOf(a.Fg) : 0;
      if (b.key === "ArrowUp") d--;
      else if (b.key === "ArrowDown") d++;
      else if (b.key === "Home") d = 0;
      else if (b.key === "End") d = c.length - 1;
      else return;
      d = (d + c.length) % c.length;
      AKa(a, c[d]);
    }
  };
  AKa = function (a, b) {
    a.Fg = b;
    b.Ei().focus();
  };
  CKa = function (a) {
    const b = a.Eg;
    if (!b.ph) {
      var c = a.Yg;
      b.ph = [
        _.yk(c, "mouseout", () => {
          b.timeout = window.setTimeout(() => {
            a.set("active", !1);
          }, 1e3);
        }),
        _.hs(c, "mouseover", a, a.Jg),
        _.yk(b, "keydown", (d) => {
          BKa(a, d);
        }),
        _.yk(
          b,
          "blur",
          () => {
            setTimeout(() => {
              b.contains(RL(a)) || a.set("active", !1);
            }, 0);
          },
          !0
        ),
      ];
      a.shadowRoot
        ? (b.ph.push(
            _.yk(a.shadowRoot, "click", (d) => {
              a.Yg.contains(d.target) || a.set("active", !1);
            })
          ),
          b.ph.push(
            _.yk(document.body, "click", (d) => {
              d.target !== a.shadowRoot.host && a.set("active", !1);
            })
          ))
        : b.ph.push(
            _.yk(document.body, "click", (d) => {
              a.Yg.contains(d.target) || a.set("active", !1);
            })
          );
    }
    _.rE(b);
    a.Yg.contains(RL(a)) &&
      (c = a.Hg.find((d) => d.get("display") !== !1)) &&
      AKa(a, c);
  };
  DKa = function (a) {
    var b = a.get("mapSize");
    b = !!(a.get("display") || (b && b.width >= 200 && b.height >= 200));
    a.Yg.style.display = b ? "" : "none";
    _.Ek(a.Yg, "resize");
  };
  HKa = function (a, b, c, d) {
    const e = a.Hg === 2,
      f = document.createElement("div");
    a.Yg.appendChild(f);
    f.style.cssFloat = "left";
    _.yq(EKa, a.Yg);
    _.Cs(f, "gm-style-mtc");
    var g = _.Es(b.label, a.Yg, !0);
    g = _.OL(f, g, b.Eg, {
      title: b.alt,
      padding: [0, 17],
      height: a.Fg,
      fontSize: rL(a.Fg),
      Wx: !1,
      jB: !1,
      XD: !0,
      LI: !0,
      Ai: e,
    });
    f.style.position = "relative";
    var h = g.Ei();
    new _.Vm(h, "focusin", () => {
      f.style.zIndex = "1";
    });
    new _.Vm(h, "focusout", () => {
      f.style.zIndex = "0";
    });
    h.style.direction = "";
    b.Sn && g.bindTo("value", a, b.Sn);
    h = null;
    const k = _.en(f);
    b.Fg &&
      ((h = new FKa(a, f, b.Fg, a.Fg, g.Ei(), {
        position: new _.vl(d ? 0 : c, k.height),
        LK: d,
        Ai: e,
      })),
      GKa(f, g, h));
    a.Eg.push({ parentNode: f, mq: h });
    return (c += k.width);
  };
  GKa = function (a, b, c) {
    new _.Vm(a, "click", () => {
      c.set("active", !0);
    });
    new _.Vm(a, "mouseover", () => {
      b.get("active") && c.set("active", !0);
    });
    _.yk(b, "active_changed", () => {
      b.get("active") || c.set("active", !1);
    });
    _.sk(b, "keydown", (d) => {
      (d.key !== "ArrowDown" && d.key !== "ArrowUp") || c.set("active", !0);
    });
    _.sk(b, "click", (d) => {
      const e = _.uE(d) ? 164753 : 164752;
      _.pl(window, _.uE(d) ? "Mtcmi" : "Mtcki");
      _.M(window, e);
    });
  };
  IKa = function (a) {
    var b = a.get("mapSize");
    b = !!(a.get("display") || (b && b.width >= 200 && b.height >= 200));
    _.pE(a.Yg, b);
    _.Ek(a.Yg, "resize");
  };
  SL = function (a, b, c) {
    a.get(b) !== c && ((a.Eg = !0), a.set(b, c), (a.Eg = !1));
  };
  JKa = function (a, b) {
    b
      ? ((a.style.fontFamily = "Arial,sans-serif"),
        (a.style.fontSize = "85%"),
        (a.style.fontWeight = "bold"),
        (a.style.bottom = "1px"),
        (a.style.padding = "1px 3px"))
      : ((a.style.fontFamily = "Roboto,Arial,sans-serif"),
        (a.style.fontSize = _.ds(10)));
    a.style.textDecoration = "none";
    a.style.position = "relative";
  };
  KKa = function () {
    const a = new Image();
    a.src = _.fy["bug_report_icon.svg"];
    a.alt = "";
    a.style.height = "12px";
    a.style.verticalAlign = "-2px";
    return a;
  };
  LKa = function (a) {
    const b = _.Is("a");
    b.target = "_blank";
    b.rel = "noopener";
    b.title =
      "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google";
    _.Wn(
      b,
      "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google"
    );
    b.textContent = "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3";
    JKa(b);
    a.appendChild(b);
    return b;
  };
  TL = function (a) {
    const b = a.get("available");
    _.Ek(a.Fg, "resize");
    a.set(
      "rmiLinkData",
      b
        ? {
            label: "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3",
            tooltip:
              "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google",
            url: a.Ig,
          }
        : void 0
    );
  };
  MKa = function (a) {
    const b = a.get("available"),
      c = a.get("enabled") !== !1;
    if (b === void 0) return !1;
    a = a.get("mapTypeId");
    return b && _.rBa(a) && c && !_.Ns();
  };
  NKa = function (a, b, c) {
    a.innerText = "";
    b = b
      ? [
          _.fy["tilt_45_normal.svg"],
          _.fy["tilt_45_hover.svg"],
          _.fy["tilt_45_active.svg"],
        ]
      : [
          _.fy["tilt_0_normal.svg"],
          _.fy["tilt_0_hover.svg"],
          _.fy["tilt_0_active.svg"],
        ];
    for (const d of b)
      (b = document.createElement("img")),
        (b.alt = ""),
        (b.style.width = _.ds(rL(c))),
        (b.src = d),
        a.appendChild(b);
  };
  OKa = function (a, b, c) {
    var d = [
      _.fy["rotate_right_normal.svg"],
      _.fy["rotate_right_hover.svg"],
      _.fy["rotate_right_active.svg"],
    ];
    for (const e of d) {
      d = document.createElement("img");
      const f = _.ds(rL(b) + 2);
      d.alt = "";
      d.style.width = f;
      d.style.height = f;
      d.src = e;
      a.style.transform = c ? "scaleX(-1)" : "";
      a.appendChild(d);
    }
  };
  PKa = function (a) {
    const b = _.Is("div");
    b.style.position = "relative";
    b.style.overflow = "hidden";
    b.style.width = _.ds((3 * a) / 4);
    b.style.height = _.ds(1);
    b.style.margin = "0 5px";
    b.style.backgroundColor = "rgb(230, 230, 230)";
    return b;
  };
  QKa = function (a) {
    const b = _.uE(a) ? 164822 : 164821;
    _.pl(window, _.uE(a) ? "Rcmi" : "Rcki");
    _.M(window, b);
  };
  RKa = function (a, b) {
    pL(a.Eg, "position", "relative");
    pL(a.Eg, "display", "inline-block");
    a.Eg.style.height = _.CE(8, !0);
    pL(a.Eg, "bottom", "-1px");
    var c = b.createElement("div");
    b.appendChild(a.Eg, c);
    _.DE(c, "100%", 4);
    pL(c, "position", "absolute");
    qL(c, 0, 0);
    c = b.createElement("div");
    b.appendChild(a.Eg, c);
    _.DE(c, 4, 8);
    qL(c, 0, 0);
    c = b.createElement("div");
    b.appendChild(a.Eg, c);
    _.DE(c, 4, 8);
    pL(c, "position", "absolute");
    pL(c, "right", "0px");
    pL(c, "bottom", "0px");
    c = b.createElement("div");
    b.appendChild(a.Eg, c);
    pL(c, "position", "absolute");
    pL(c, "backgroundColor", a.Hg ? "#fff" : "#000000");
    c.style.height = _.CE(2, !0);
    pL(c, "left", "1px");
    pL(c, "bottom", "1px");
    pL(c, "right", "1px");
    c = b.createElement("div");
    b.appendChild(a.Eg, c);
    pL(c, "position", "absolute");
    _.DE(c, 2, 6);
    qL(c, 1, 1);
    pL(c, "backgroundColor", a.Hg ? "#fff" : "#000000");
    c = b.createElement("div");
    b.appendChild(a.Eg, c);
    _.DE(c, 2, 6);
    pL(c, "position", "absolute");
    pL(c, "backgroundColor", a.Hg ? "#fff" : "#000000");
    pL(c, "bottom", "1px");
    pL(c, "right", "1px");
  };
  UL = function (a) {
    var b = a.Kg.get();
    b &&
      ((b *= 80),
      (b = a.Jg ? SKa(b / 1e3, b, !0) : SKa(b / 1609.344, b * 3.28084, !1)),
      (a.Ig.textContent = b.Ar + "\u00a0"),
      a.Yg.setAttribute("aria-label", b.aE),
      (a.Yg.title = b.aE),
      (a.Eg.style.width = _.CE(b.qK + 4, !0)),
      _.Ek(a.Yg, "resize"));
  };
  SKa = function (a, b, c) {
    var d = a;
    let e = c ? "km" : "d\u1eb7m";
    a < 1 && ((d = b), (e = c ? "m" : "b\u1ed9"));
    for (b = 1; d >= b * 10; ) b *= 10;
    d >= b * 5 && (b *= 5);
    d >= b * 2 && (b *= 2);
    d = Math.round((80 * b) / d);
    let f = c
      ? "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " + b + " km/" + d + " pixel"
      : "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " +
        b +
        " d\u1eb7m/" +
        d +
        " pixel";
    a < 1 &&
      (f = c
        ? "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " + b + " m/" + d + " pixel"
        : "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " +
          b +
          " b\u1ed9/" +
          d +
          " pixel");
    return { qK: d, Ar: `${b} ${e}`, aE: f };
  };
  WL = function (a) {
    _.yG.call(this, a, VL);
    _.QF(a, VL) ||
      _.PF(
        a,
        VL,
        { options: 0 },
        [
          "div",
          ,
          1,
          0,
          [
            " ",
            ["img", 8, 1, 1],
            " ",
            [
              "button",
              ,
              1,
              2,
              [
                " ",
                ["img", 8, 1, 3],
                " ",
                ["img", 8, 1, 4],
                " ",
                ["img", 8, 1, 5],
                " ",
              ],
            ],
            " ",
            [
              "button",
              ,
              1,
              6,
              [
                " ",
                ["img", 8, 1, 7],
                " ",
                ["img", 8, 1, 8],
                " ",
                ["img", 8, 1, 9],
                " ",
              ],
            ],
            " ",
            [
              "button",
              ,
              1,
              10,
              [
                " ",
                ["img", 8, 1, 11],
                " ",
                ["img", 8, 1, 12],
                " ",
                ["img", 8, 1, 13],
                " ",
              ],
            ],
            " <div> ",
            ["div", , , 14, ["Xoay ch\u1ebf \u0111\u1ed9 xem"]],
            " ",
            ["div", , , 15],
            " ",
            ["div", , , 16],
            " </div> ",
          ],
        ],
        [],
        TKa()
      );
  };
  UKa = function (a) {
    return _.pF(a.options, "", (b) => _.L(b.Gg, 10));
  };
  VKa = function (a) {
    return _.pF(
      a.options,
      "",
      (b) => _.Gi(b.Gg, 7, _.EG),
      (b) => _.DG(b)
    );
  };
  WKa = function (a) {
    return _.pF(
      a.options,
      "",
      (b) => _.Gi(b.Gg, 8, _.EG),
      (b) => _.DG(b)
    );
  };
  XKa = function (a) {
    return _.pF(
      a.options,
      "",
      (b) => _.Gi(b.Gg, 9, _.EG),
      (b) => _.DG(b)
    );
  };
  YKa = function (a) {
    return _.pF(a.options, "", (b) => _.L(b.Gg, 12));
  };
  ZKa = function (a) {
    return _.pF(a.options, "", (b) => _.L(b.Gg, 11));
  };
  TKa = function () {
    return [
      ["$t", "t-avKK8hDgg9Q", "$a", [7, , , , , "gm-compass"]],
      [
        "$a",
        [
          8,
          ,
          ,
          ,
          function (a) {
            return _.pF(
              a.options,
              "",
              (b) => _.Gi(b.Gg, 3, _.EG),
              (b) => _.DG(b)
            );
          },
          "src",
          ,
          ,
          1,
        ],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "48", "width", , 1],
      ],
      [
        "$a",
        [7, , , , , "gm-control-active", , 1],
        "$a",
        [7, , , , , "gm-compass-turn", , 1],
        "$a",
        [0, , , , UKa, "aria-label", , , 1],
        "$a",
        [0, , , , UKa, "title", , , 1],
        "$a",
        [0, , , , "button", "type", , 1],
        "$a",
        [
          22,
          ,
          ,
          ,
          function () {
            return "compass.counterclockwise";
          },
          "jsaction",
          ,
          1,
        ],
      ],
      [
        "$a",
        [8, , , , VKa, "src", , , 1],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "14", "width", , 1],
      ],
      [
        "$a",
        [8, , , , WKa, "src", , , 1],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "14", "width", , 1],
      ],
      [
        "$a",
        [8, , , , XKa, "src", , , 1],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "14", "width", , 1],
      ],
      [
        "$a",
        [7, , , , , "gm-control-active", , 1],
        "$a",
        [7, , , , , "gm-compass-needle", , 1],
        "$a",
        [0, , , , YKa, "aria-label", , , 1],
        "$a",
        [0, , , , YKa, "title", , , 1],
        "$a",
        [0, , , , "button", "type", , 1],
        "$a",
        [
          22,
          ,
          ,
          ,
          function () {
            return "compass.north";
          },
          "jsaction",
          ,
          1,
        ],
      ],
      [
        "$a",
        [
          8,
          ,
          ,
          ,
          function (a) {
            return _.pF(
              a.options,
              "",
              (b) => _.Gi(b.Gg, 4, _.EG),
              (b) => _.DG(b)
            );
          },
          "src",
          ,
          ,
          1,
        ],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "20", "width", , 1],
      ],
      [
        "$a",
        [
          8,
          ,
          ,
          ,
          function (a) {
            return _.pF(
              a.options,
              "",
              (b) => _.Gi(b.Gg, 5, _.EG),
              (b) => _.DG(b)
            );
          },
          "src",
          ,
          ,
          1,
        ],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "20", "width", , 1],
      ],
      [
        "$a",
        [
          8,
          ,
          ,
          ,
          function (a) {
            return _.pF(
              a.options,
              "",
              (b) => _.Gi(b.Gg, 6, _.EG),
              (b) => _.DG(b)
            );
          },
          "src",
          ,
          ,
          1,
        ],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "20", "width", , 1],
      ],
      [
        "$a",
        [7, , , , , "gm-control-active", , 1],
        "$a",
        [7, , , , , "gm-compass-turn", , 1],
        "$a",
        [7, , , , , "gm-compass-turn-opposite", , 1],
        "$a",
        [0, , , , ZKa, "aria-label", , , 1],
        "$a",
        [0, , , , ZKa, "title", , , 1],
        "$a",
        [0, , , , "button", "type", , 1],
        "$a",
        [
          22,
          ,
          ,
          ,
          function () {
            return "compass.clockwise";
          },
          "jsaction",
          ,
          1,
        ],
      ],
      [
        "$a",
        [8, , , , VKa, "src", , , 1],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "14", "width", , 1],
      ],
      [
        "$a",
        [8, , , , WKa, "src", , , 1],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "14", "width", , 1],
      ],
      [
        "$a",
        [8, , , , XKa, "src", , , 1],
        "$a",
        [0, , , , "", "alt", , 1],
        "$a",
        [0, , , , "false", "draggable", , 1],
        "$a",
        [0, , , , "48", "height", , 1],
        "$a",
        [0, , , , "14", "width", , 1],
      ],
      ["$a", [7, , , , , "gm-compass-tooltip-text", , 1]],
      [
        "$a",
        [7, , , , , "gm-compass-arrow-right", , 1],
        "$a",
        [7, , , , , "gm-compass-arrow-right-outer", , 1],
      ],
      [
        "$a",
        [7, , , , , "gm-compass-arrow-right", , 1],
        "$a",
        [7, , , , , "gm-compass-arrow-right-inner", , 1],
      ],
    ];
  };
  $Ka = function (a, b) {
    return b ? (b.every((c) => a.Vs.includes(c)), b) : a.Vs;
  };
  aLa = function (a, b, c, d) {
    const e = VJa(c, a.Fg, d);
    b.appendChild(e);
    _.yk(e, "click", (f) => {
      var g = c === 0 ? 1 : -1;
      a.set("zoom", a.get("zoom") + g);
      g = _.uE(f) ? 164935 : 164934;
      _.pl(window, _.uE(f) ? "Zcmi" : "Zcki");
      _.M(window, g);
    });
    e.style.backgroundColor = d === 2 ? "#444" : "#fff";
    return e;
  };
  bLa = function (a) {
    var b = a.get("mapSize");
    b = (b && b.width >= 200 && b.height >= 200) || !!a.get("display");
    a.Kg = b;
    if (a.Kg) {
      _.rE(a.Yg);
      b = a.Fg;
      var c = 2 * a.Fg + 1;
      a.Eg.style.width = _.ds(b);
      a.Eg.style.height = _.ds(c);
      a.Yg.dataset.controlWidth = String(b);
      a.Yg.dataset.controlHeight = String(c);
      _.Ek(a.Yg, "resize");
      b = a.Ig.style;
      b.width = _.ds(a.Fg);
      b.height = _.ds(a.Fg);
      b.left = b.top = "0";
      a.Hg.style.top = "0";
      b = a.Jg.style;
      b.width = _.ds(a.Fg);
      b.height = _.ds(a.Fg);
      b.left = b.top = "0";
    } else _.qE(a.Yg);
  };
  cLa = function (a, b) {
    const c = XL[b];
    tL(a.Ig, 0, a.Fg, b);
    tL(a.Jg, 1, a.Fg, b);
    a.Eg.style.backgroundColor = c.backgroundColor;
    a.Hg.style.backgroundColor = c.hD;
  };
  dLa = function (a) {
    a.pw && (a.pw.unbindAll(), (a.pw = null));
  };
  fLa = function (a, b, c) {
    const d = document.createElement("div");
    return new eLa(d, a, b, c);
  };
  YL = function (a) {
    let b =
      a.get("attributionText") ||
      "H\u00ecnh \u1ea3nh c\u00f3 th\u1ec3 c\u00f3 b\u1ea3n quy\u1ec1n";
    a.Jg && (b = b.replace("Map data", "Map Data"));
    _.vE(a.Ig, b);
    _.Ek(a.Eg, "resize");
  };
  hLa = function () {
    const a = document.createElement("div");
    return new gLa(a);
  };
  jLa = function (a, b) {
    const c = document.createElement("div");
    return new iLa(c, a, b);
  };
  kLa = function (a, b, c) {
    _.yk(b, "mouseover", () => {
      b.style.color = "#bbb";
      b.style.fontWeight = "bold";
    });
    _.yk(b, "mouseout", () => {
      b.style.color = "#999";
      b.style.fontWeight = "400";
    });
    _.hs(b, "click", a, (d) => {
      a.set("pano", c);
      const e = _.uE(d) ? 171224 : 171223;
      _.pl(window, _.uE(d) ? "Ecmi" : "Ecki");
      _.M(window, e);
    });
  };
  lLa = function (a) {
    const b = document.createElement("img");
    b.src = _.fy["pegman_dock_normal.svg"];
    b.style.width = b.style.height = _.ds(a);
    b.style.position = "absolute";
    b.style.transform = "translate(-50%, -50%)";
    b.alt =
      "Ki\u1ec3m so\u00e1t ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o trong ch\u1ebf \u0111\u1ed9 xem ph\u1ed1";
    b.style.pointerEvents = "none";
    return b;
  };
  mLa = function (a) {
    const b = document.createElement("img");
    b.src = _.fy["pegman_dock_active.svg"];
    b.style.display = "none";
    b.style.width = b.style.height = _.ds(a);
    b.style.position = "absolute";
    b.style.transform = "translate(-50%, -50%)";
    b.alt =
      "Ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o \u1edf \u0111\u1ea7u B\u1ea3n \u0111\u1ed3";
    b.style.pointerEvents = "none";
    return b;
  };
  nLa = function (a) {
    const b = document.createElement("img");
    b.style.display = "none";
    b.style.width = b.style.height = _.ds((a * 4) / 3);
    b.style.position = "absolute";
    b.style.transform = "translate(-60%, -45%)";
    b.style.pointerEvents = "none";
    b.alt =
      "Ki\u1ec3m so\u00e1t ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o trong ch\u1ebf \u0111\u1ed9 xem ph\u1ed1";
    b.src = _.fy["pegman_dock_hover.svg"];
    return b;
  };
  pLa = function (a) {
    const b = a.Yg;
    a.Yg.textContent = "";
    if (a.visible) {
      b.style.display = "";
      var c = new _.xl(a.Eg, a.Eg);
      b.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
      b.style.borderRadius = _.ds(a.Eg > 40 ? Math.round(a.Eg / 20) : 2);
      b.style.width = _.ds(c.width);
      b.style.height = _.ds(c.height);
      var d = document.createElement("div");
      b.appendChild(d);
      d.style.position = "absolute";
      d.style.left = "50%";
      d.style.top = "50%";
      d.append(a.Fg.Yz, a.Fg.active, a.Fg.Xz);
      d.style.transform = "scaleX(var(--pegman-scaleX))";
      b.dataset.controlWidth = String(c.width);
      b.dataset.controlHeight = String(c.height);
      _.Ek(b, "resize");
      oLa(a, a.get("mode"));
    } else (b.style.display = "none"), _.Ek(b, "resize");
  };
  qLa = function (a) {
    var b = a.get("mapSize");
    b = !!a.get("display") || !!(b && b.width >= 200 && b && b.height >= 200);
    a.visible != b && ((a.visible = b), pLa(a));
  };
  oLa = function (a, b) {
    a.visible &&
      ((a = a.Fg),
      (a.Yz.style.display =
        a.Xz.style.display =
        a.active.style.display =
          "none"),
      b === 1
        ? (a.Yz.style.display = "")
        : b === 2
        ? (a.Xz.style.display = "")
        : (a.active.style.display = ""));
  };
  rLa = function (a) {
    a = sL(a.Pg, 0);
    return _.MG(a.url, null, a.origin, a.size, null, a.scaledSize);
  };
  sLa = function (a) {
    const b = document.createElement("div");
    b.style.height = a.style.height;
    b.style.width = a.style.width;
    b.appendChild(a);
    return b;
  };
  tLa = function (a) {
    return new Promise(async (b) => {
      var c = await _.jj("marker");
      const d = a.Fg();
      c = c.PC({
        content: a.Ng,
        oz: !0,
        dragIndicator: document.createElement("span"),
        gmpDraggable: !0,
        map: d === 0 || d === 1 ? null : a.map,
        zIndex: 1e6,
      });
      b(c);
    });
  };
  vLa = async function (a) {
    if (!a.Lg) {
      const b = await a.Hg;
      a.set("dragPosition", b.position && new _.ek(b.position));
      _.Ek(a, "dragend");
    }
    uLa(a);
  };
  wLa = async function (a) {
    const b = await a.Hg;
    _.Dk(b, "dragstart", a);
    _.Dk(b, "drag", a);
    _.sk(b, "dragend", a.Wg);
    _.sk(b, "longpressdragstart", () => {
      a.Og = !0;
    });
    _.sk(b, "dragcancel", a.Vg);
  };
  zLa = function (a) {
    const b = a.Fg();
    if (_.qJ(b)) {
      var c = a.Fg() - 3;
      c = sL(a.Pg, c);
    } else
      b === 7
        ? ((c = xLa(a)),
          a.Tg !== c &&
            ((a.Tg = c),
            (a.Sg = {
              url: yLa[c],
              size: new _.xl(49, 52),
              scaledSize: new _.xl(49, 52),
              origin: new _.vl(0, 0),
            })),
          (c = a.Sg))
        : (c = null);
    c
      ? (a.Ig.firstChild.__src__ !== c.url && _.LG(a.Ig.firstChild, c.url),
        _.NG(a.Ig, c.size || null, c.origin || null, c.scaledSize),
        c.size &&
          ((a.Ng.style.height = `${c.size.height}px`),
          (a.Ng.style.width = `${c.size.width}px`)),
        (a.Ig.style.top = b === 7 ? "50%" : ""),
        (a.Ig.style.display = ""))
      : (a.Ig.style.display = "none");
  };
  ALa = function (a) {
    a.Jx.setVisible(!1);
    a.Mg.setVisible(_.qJ(a.Fg()));
  };
  ZL = async function (a) {
    const b = await a.Hg;
    b.Bk
      ? a.set("dragPosition", b.position && new _.ek(b.position))
      : a.Og &&
        (a.set("dragPosition", b.position && new _.ek(b.position)),
        (a.Og = !1));
  };
  BLa = function (a, b) {
    var c = b.domEvent;
    b = b.pixel;
    c instanceof KeyboardEvent
      ? _.Xw(c)
        ? a.Eg(5)
        : _.Vw(c) && a.Eg(3)
      : ((c = b?.x ?? 0),
        c > a.Kg + 5
          ? (a.Eg(5), (a.Kg = c))
          : c < a.Kg - 5 && (a.Eg(3), (a.Kg = c)));
  };
  uLa = function (a) {
    window.clearTimeout(a.Jg);
    a.Jg = 0;
    a.set("dragging", !1);
    a.Eg(1);
    a.Lg = !1;
  };
  xLa = function (a) {
    (a = _.gE(a.get("heading")) % 360) || (a = 0);
    a < 0 && (a += 360);
    return Math.round((a / 360) * 16) % 16;
  };
  GLa = function (a, b, c) {
    var d = a.map.__gm;
    const e = new CLa(
      b,
      a.controlSize,
      (g) => {
        a.marker.ys(g);
      },
      (g) => {
        a.marker.zs(g);
      },
      a.Ai
    );
    e.bindTo("mode", a);
    e.bindTo("mapSize", a);
    e.bindTo("display", a);
    e.bindTo("isOnLeft", a);
    a.marker.bindTo("mode", a);
    a.marker.bindTo("dragPosition", a);
    a.marker.bindTo("position", a);
    const f = new _.hK(["mapHeading", "streetviewHeading"], "heading", DLa);
    f.bindTo("streetviewHeading", a, "heading");
    f.bindTo("mapHeading", a.map, "heading");
    a.marker.bindTo("heading", f);
    a.bindTo("pegmanDragging", a.marker, "dragging");
    d.bindTo("pegmanDragging", a);
    _.Ak(e, "dragstart", a, () => {
      a.offset = _.AJ(b, a.Og);
      ELa(a);
    });
    d = ["dragstart", "drag", "dragend"];
    for (const g of d)
      _.sk(e, g, () => {
        _.Ek(a.marker, g, {
          latLng: a.marker.get("position"),
          pixel: e.get("position"),
        });
      });
    _.sk(e, "position_changed", () => {
      var g = e.get("position");
      (g = c({ clientX: g.x + a.offset.x, clientY: g.y + a.offset.y })) &&
        a.marker.set("dragPosition", g);
    });
    _.sk(a.marker, "dragstart", () => {
      ELa(a);
    });
    _.sk(a.marker, "dragend", async () => {
      await FLa(a, !1);
    });
    _.sk(a.marker, "hover", async () => {
      await FLa(a, !0);
    });
  };
  ELa = async function (a) {
    var b = await _.jj("streetview");
    if (!a.Eg) {
      var c = a.map.__gm,
        d = (0, _.Da)(a.Kg.getUrl, a.Kg),
        e = c.get("panes");
      a.Eg = new b.iG(e.floatPane, d, a.config);
      a.Eg.bindTo("description", a);
      a.Eg.bindTo("mode", a);
      a.Eg.bindTo("thumbnailPanoId", a, "panoId");
      a.Eg.bindTo("pixelBounds", c);
      b = new _.GK((f) => {
        f = new _.gy(a.map, a.ah, f);
        a.ah.Ii(f);
        return f;
      });
      b.bindTo("latLngPosition", a.marker, "dragPosition");
      a.Eg.bindTo("pixelPosition", b);
    }
  };
  FLa = async function (a, b) {
    const c = a.get("dragPosition");
    var d = a.map.getZoom();
    d = Math.max(50, Math.pow(2, 16 - d) * 35);
    a.set("hover", b);
    a.Jg = !1;
    const e = await _.jj("streetview"),
      f = a.hp || void 0;
    a.Fg ||
      ((a.Fg = new e.hG(f)),
      a.bindTo("sloTrackingId", a.Fg, "sloTrackingId", !0),
      a.bindTo("isHover", a.Fg, "isHover", !0),
      a.Fg.bindTo("result", a, null, !0));
    a.Fg.getPanoramaByLocation(
      c,
      d,
      f ? void 0 : d < 100 ? "nearest" : "best",
      b,
      a.map.get("streetViewControlOptions")?.sources
    );
  };
  DLa = function (a, b) {
    return _.vj(b - (a || 0), 0, 360);
  };
  $L = function () {
    return _.Mi.Eg().Fg() === "CH";
  };
  HLa = function (a) {
    _.nL(a);
    a.style.fontSize = "10px";
    a.style.height = "17px";
    a.style.backgroundColor = "#f5f5f5";
    a.style.border = "1px solid #dcdcdc";
    a.style.lineHeight = "19px";
  };
  ILa = function (a) {
    a = {
      content: new _.LK({
        fp: a.fp,
        gp: a.gp,
        ownerElement: a.ownerElement,
        Rv: !0,
        Js: a.Js,
      }).element,
      title: "Ph\u00edm t\u1eaft",
    };
    a = new _.FK(a);
    _.Bl(a, "keyboard-shortcuts-dialog-view");
    return a;
  };
  JLa = function () {
    return "@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}";
  };
  KLa = function (a) {
    if (!_.an[2]) {
      var b = !!_.an[21];
      a.Eg
        ? (b = uKa(a.Eg, a.pi, b, a.Ug))
        : ((b = new tKa(a.Fg, a.pi, b)), sKa(b, !0));
      b = b.getDiv();
      a.Hg.addElement(b, 23, !0, -1e3);
      a.set("logoWidth", b.offsetWidth);
    }
  };
  NLa = function (a) {
    const b = new LLa(a.Zg, a.Lg, a.Ph, a.si, a.Tg);
    b.bindTo("size", a);
    b.bindTo("rmiWidth", a);
    b.bindTo("attributionText", a);
    b.bindTo("fontLoaded", a);
    b.bindTo("mapTypeId", a);
    b.bindTo("isCustomPanorama", a);
    b.Eg.addListener("click", (c) => {
      a.nh || (a.nh = MLa(a));
      a.Ph.__gm.get("developerProvidedDiv").appendChild(a.nh);
      a.nh.Eg.showModal();
      const d = _.uE(c) ? 164970 : 164969;
      _.pl(window, _.uE(c) ? "Kscmi" : "Kscki");
      _.M(window, d);
    });
    return b;
  };
  PLa = function (a) {
    if (a.Fg) {
      var b = document.createElement("div");
      a.Sg = new OLa(b, a.dj);
      a.Sg.bindTo("pov", a.Fg);
      a.Sg.bindTo("pano", a.Fg);
      a.Sg.bindTo("takeDownUrl", a.Fg);
      a.Fg.set("rmiWidth", b.offsetWidth);
      _.an[17] &&
        (a.Sg.bindTo("visible", a.Fg, "reportErrorControl"),
        a.Fg.bindTo("rmiLinkData", a.Sg));
    }
  };
  RLa = function (a) {
    if (a.Eg) {
      var b = _.eu("Map Scale");
      _.Ks(b);
      _.Ls(b);
      var c = _.HL(b, a.Lg, a.Tg);
      a.dh = new QLa(
        b,
        c,
        new _.hy(
          [
            new _.Ey(a, "projection"),
            new _.Ey(a, "bottomRight"),
            new _.Ey(a, "zoom"),
          ],
          _.BDa
        ),
        a.Tg
      );
      aM(a);
    }
  };
  TLa = function (a) {
    if (a.Eg) {
      var b = _.Mi.Eg(),
        c = document.createElement("div");
      a.Jg = new SLa(c, a.Eg, _.L(b.Gg, 15), a.Tg);
      a.Jg.bindTo("available", a, "rmiAvailable");
      a.Jg.bindTo("bounds", a);
      _.an[17]
        ? (a.Jg.bindTo("enabled", a, "reportErrorControl"),
          a.Eg.bindTo("rmiLinkData", a.Jg))
        : a.Jg.set("enabled", !0);
      a.Jg.bindTo("mapTypeId", a);
      a.Jg.bindTo("sessionState", a.Gk);
      a.bindTo("rmiWidth", a.Jg, "width");
      _.sk(a.Jg, "rmilinkdata_changed", () => {
        const d = a.Jg.get("rmiLinkData");
        a.Eg.set("rmiUrl", d && d.url);
      });
    }
  };
  VLa = function (a) {
    a.Vg && (a.Vg.unbindAll(), jKa(a.Vg), (a.Vg = null), a.Hg.nl(a.Bi));
    const b = _.eu(
        "Chuy\u1ec3n \u0111\u1ed5i ch\u1ebf \u0111\u1ed9 xem to\u00e0n m\u00e0n h\u00ecnh"
      ),
      c = new ULa(a.Lg, b, a.sk, a.Kg, a.Ug);
    c.bindTo("display", a, "fullscreenControl");
    c.bindTo("disableDefaultUI", a);
    c.bindTo("mapTypeId", a);
    const d = a.get("fullscreenControlOptions") || {};
    a.Hg.addElement(b, (d && d.position) || 20, !0, -1007);
    a.Vg = c;
    a.Bi = b;
  };
  WLa = function (a, b) {
    const c = a.Hg;
    for (a = b.length - 1; a >= 0; a--) {
      let d = a;
      const e = b[a];
      if (!e) break;
      const f = (g) => {
        if (g) {
          var h = g.index;
          _.xj(h) || (h = 1e3);
          h = Math.max(h, -999);
          _.Js(g, Math.min(999999, _.gE(g.style.zIndex || 0)));
          c.addElement(g, d, !1, h);
        }
      };
      e.forEach(f);
      _.sk(e, "insert_at", (g) => {
        f(e.getAt(g));
      });
      _.sk(e, "remove_at", (g, h) => {
        c.nl(h);
      });
    }
  };
  YLa = function (a) {
    a.sh = new XLa(a.Mg.Eg, a.Zg);
    const b = a.sh.Yg;
    a.tj
      ? a.Lg.insertBefore(b, a.Lg.children[0])
      : a.Zg.insertBefore(b, a.Zg.children[0]);
  };
  $La = function (a) {
    if (a.Eg) {
      var b = [a.Mg.Eg, a.Mg.Fg, a.Mg.Hg, a.dh, a.Mg.Ig];
      a.Jg && b.push(a.Jg);
    } else b = [a.Mg.Eg, a.Mg.Fg, a.Mg.Hg, a.Mg.Ig, a.Sg];
    b = new ZLa({ Vs: b });
    a.Hg.addElement(b.Yg, 25, !0);
    return b;
  };
  bMa = function (a) {
    if (a.Eg) {
      var b = a.Eg,
        c = document.createElement("div");
      c = new aMa(c);
      c.bindTo("card", b.__gm);
      b = c.getDiv();
      a.Hg.addElement(b, 14, !0, 0.1);
    }
  };
  dMa = function (a) {
    _.jj("util").then((b) => {
      b.Lo.Eg(() => {
        a.Jh = !0;
        cMa(a);
        a.Og && (a.Og.set("display", !1), a.Og.unbindAll(), (a.Og = null));
      });
    });
  };
  sMa = function (a) {
    a.Qg && (dLa(a.Qg), a.Qg.unbindAll(), (a.Qg = null));
    a.Ig && (a.Ig = null);
    a.Ng && (a.Ng.unbindAll(), (a.Ng = null));
    a.lh && (a.lh.unbindAll(), (a.lh = null));
    for (var b of a.Ih) eMa(a, b);
    a.Ih = [];
    a.Hg &&
      _.Bk(a.Hg, "isrtl_changed", () => {
        bM(a);
      });
    b = a.pj = fMa(a);
    var c = (a.Zi = gMa(a)),
      d = (a.qj = hMa(a)),
      e = (a.fi = cM(a)),
      f = (a.cj = iMa(a));
    a.Wi = jMa(a);
    var g = (p) => (a.get(p) || {}).position,
      h = b && (g("panControlOptions") || 22);
    b = d && (g("zoomControlOptions") || (d == 3 && 19) || 22);
    const k = c && (g("cameraControlOptions") || 22);
    c = d == 3 || _.Ns();
    e = e && (g("streetViewControlOptions") || 22);
    f = f && (g("rotateControlOptions") || (c && 19) || 22);
    const m = a.tk;
    g = (p, t) => {
      const u = ML(a.Hg, p);
      if (!m[u]) {
        const w = a.Kg >> 2,
          x = 12 + (a.Kg >> 1),
          z = document.createElement("div");
        _.nL(z);
        _.Cs(z, "gm-bundled-control");
        u === 10 || u === 11 || u === 12 || u === 6 || u === 9
          ? _.Cs(z, "gm-bundled-control-on-bottom")
          : _.lL(z, "gm-bundled-control-on-bottom");
        z.style.margin = _.ds(w);
        _.Ks(z);
        m[u] = new kMa(z, u, x);
        a.Hg.addElement(z, p, !1, 0.1);
      }
      p = m[u];
      p.add(t);
      a.Ih.push({ mh: t, Hx: p });
    };
    c = [1, 5, 4, 6, 10];
    a.Hg.get("isRTL") && c.push(2, 13, 11);
    b && ((d = lMa(a)), g(b, d));
    e &&
      (mMa(a),
      g(e, a.di),
      a.Og && a.Hg && a.Og.set("isOnLeft", c.includes(ML(a.Hg, e))));
    k && ((e = c.includes(ML(a.Hg, k))), (e = nMa(a, e)), g(k, e));
    h && a.Fg && _.As().transform && ((e = oMa(a)), g(h, e));
    f && ((h = pMa(a)), g(f, h));
    a.Wg && (a.Wg.remove(), (a.Wg = null));
    if ((h = qMa(a) && 22)) (e = rMa(a)), g(h, e);
    a.Ng && a.Qg && a.Qg.pw && f == b && a.Ng.bindTo("mouseover", a.Qg.pw);
    for (const p of a.Ih) _.Ek(p.mh, "resize");
    a.Ig &&
      setTimeout(() => {
        const p = ML(a.Hg, k);
        a.Ig?.Vg(m[p]);
      }, 0);
  };
  yMa = function (a) {
    cMa(a);
    if (a.Vh && !a.Jh) {
      var b = tMa(a);
      if (b) {
        var c = _.Is("div");
        _.nL(c);
        c.style.margin = _.ds(a.Kg >> 2);
        _.yk(c, "mouseover", () => {
          _.Js(c, 1e6);
        });
        _.yk(c, "mouseout", () => {
          _.Js(c, 0);
        });
        _.Js(c, 0);
        var d = a.get("mapTypeControlOptions") || {},
          e = (a.gh = new uMa(a.Vh, d.mapTypeIds));
        e.bindTo("aerialAvailableAtZoom", a);
        e.bindTo("zoom", a);
        var f = e.buttons;
        a.Hg.addElement(c, d.position || 14, !1, 0.2);
        d = null;
        b == 2
          ? ((d = new vMa(c, f, a.Kg, a.Ug)), e.bindTo("mapTypeId", d))
          : (d = new wMa(c, f, a.Kg, a.Ug));
        b = a.Ah = new xMa(e.mapping);
        b.set("labels", !0);
        d.bindTo("mapTypeId", b, "internalMapTypeId");
        d.bindTo("labels", b);
        d.bindTo("terrain", b);
        d.bindTo("tilt", a, "desiredTilt");
        d.bindTo("fontLoaded", a);
        d.bindTo("mapSize", a, "size");
        d.bindTo("display", a, "mapTypeControl");
        b.bindTo("mapTypeId", a);
        _.Ek(c, "resize");
        a.Xg = { mh: c, Hx: null };
        a.Bh = d;
      }
    }
  };
  cMa = function (a) {
    a.Bh && (a.Bh.unbindAll && a.Bh.unbindAll(), (a.Bh = null));
    a.Ah && (a.Ah.unbindAll(), (a.Ah = null));
    a.gh && (a.gh.unbindAll(), (a.gh = null));
    a.Xg && (eMa(a, a.Xg), _.vn(a.Xg.mh), (a.Xg = null));
  };
  hMa = function (a) {
    const b = a.get("zoomControl"),
      c = dM(a);
    return b == 0 || (c && b === void 0)
      ? (a.Fg || (_.pl(a.Eg, "Czn"), _.M(a.Eg, 148262)), null)
      : a.get("size")
      ? 1
      : null;
  };
  gMa = function (a) {
    const b = a.get("cameraControl"),
      c = dM(a);
    if (!a.get("size") || a.Fg) return !1;
    (a.get("cameraControl") !== void 0 || c) && _.M(a.Eg, b ? 226848 : 226002);
    return b == 1;
  };
  fMa = function (a) {
    var b = a.get("panControl");
    const c = dM(a);
    if (b !== void 0 || c)
      return (
        a.Fg || (_.pl(a.Eg, b ? "Cpy" : "Cpn"), _.M(a.Eg, b ? 148255 : 148254)),
        !!b
      );
    b = a.get("size");
    return _.Ns() || !b ? !1 : (b.width >= 400 && b.height >= 370) || !!a.Fg;
  };
  iMa = function (a) {
    const b = a.get("rotateControl"),
      c = dM(a);
    if (b !== void 0 || c)
      _.pl(a.Eg, b ? "Cry" : "Crn"), _.M(a.Eg, b ? 148257 : 148256);
    return !a.get("size") || a.Fg ? !1 : c ? b == 1 : b != 0;
  };
  cM = function (a) {
    let b = a.get("streetViewControl");
    const c = a.get("disableDefaultUI"),
      d = !!a.get("size");
    if (b !== void 0 || c)
      _.pl(a.Eg, b ? "Cvy" : "Cvn"), _.M(a.Eg, b ? 148260 : 148261);
    b == null && (b = !c);
    a = d && !a.Fg;
    return b && a;
  };
  jMa = function (a) {
    return a.Fg
      ? !1
      : dM(a)
      ? a.get("myLocationControl") == 1
      : a.get("myLocationControl") != 0;
  };
  zMa = function (a) {
    if (
      hMa(a) != a.qj ||
      gMa(a) != a.Zi ||
      fMa(a) != a.pj ||
      iMa(a) != a.cj ||
      cM(a) != a.fi ||
      jMa(a) != a.Wi
    )
      a.Pg[1] = !0;
    a.Pg[0] = !0;
    _.Om(a.Rg);
  };
  aM = function (a) {
    if (a.dh) {
      var b = a.get("scaleControl");
      b !== void 0 &&
        (_.pl(a.Eg, b ? "Csy" : "Csn"), _.M(a.Eg, b ? 148259 : 148258));
      b ? a.dh.enable() : a.dh.disable();
    }
  };
  dM = function (a) {
    return a.get("disableDefaultUI");
  };
  qMa = function (a) {
    return !a.get("disableDefaultUI") && !!a.Fg;
  };
  MLa = function (a) {
    const b = a.Ph.__gm.get("developerProvidedDiv"),
      c = ILa({
        fp: a.Pj,
        gp: a.rk,
        ownerElement: b,
        Js: a.Eg ? "map" : "street_view",
      });
    c.addEventListener("close", () => {
      b.removeChild(c);
    });
    return c;
  };
  eMa = function (a, b) {
    b.Hx ? (b.Hx.remove(b.mh), delete b.Hx) : a.Hg.nl(b.mh);
  };
  tMa = function (a) {
    if (!a.Vh) return null;
    const b = (a.get("mapTypeControlOptions") || {}).style || 0,
      c = a.get("mapTypeControl"),
      d = dM(a);
    if ((c === void 0 && d) || (c !== void 0 && !c))
      return _.pl(a.Eg, "Cmn"), _.M(a.Eg, 148251), null;
    b == 1
      ? (_.pl(a.Eg, "Cmh"), _.M(a.Eg, 148253))
      : b == 2 && (_.pl(a.Eg, "Cmd"), _.M(a.Eg, 148252));
    return b == 2 || b == 1 ? b : 1;
  };
  lMa = function (a) {
    const b = (a.Qg = new AMa(a.Kg, a.Lg, a.Ug));
    b.bindTo("zoomRange", a);
    b.bindTo("display", a, "zoomControl");
    b.bindTo("disableDefaultUI", a);
    b.bindTo("mapSize", a, "size");
    b.bindTo("mapTypeId", a);
    b.bindTo("zoom", a);
    return b.getDiv();
  };
  nMa = function (a, b = !1) {
    a.Ig = new BMa({ controlSize: a.Kg, av: b, yp: a.Lg });
    a.Ig.Rg(a.get("cameraControl"), a.get("size"));
    a.Ig.Tg(a.get("mapTypeId"));
    _.sk(a.Ig, "panbyfraction", (c, d) => {
      _.Ek(a, "panbyfraction", c, d);
    });
    _.sk(a.Ig, "zoomMap", (c) => {
      c = c === 0 ? 1 : -1;
      a.set("zoom", a.get("zoom") + c);
    });
    return a.Ig;
  };
  oMa = function (a) {
    const b = new _.MK(WL, { Oq: _.Ly.Fj() }),
      c = new CMa(b, a.Kg, a.Lg);
    c.bindTo("pov", a);
    c.bindTo("disableDefaultUI", a);
    c.bindTo("panControl", a);
    c.bindTo("mapSize", a, "size");
    return b.mh;
  };
  pMa = function (a) {
    const b = _.Is("div");
    _.nL(b);
    a.Ng = new DMa(b, a.Kg, a.Lg);
    a.Ng.bindTo("mapSize", a, "size");
    a.Ng.bindTo("rotateControl", a);
    a.Ng.bindTo("heading", a);
    a.Ng.bindTo("tilt", a);
    a.Ng.bindTo("aerialAvailableAtZoom", a);
    return b;
  };
  rMa = function (a) {
    const b = _.Is("div"),
      c = (a.lh = new EMa(b, a.Kg));
    c.bindTo("pano", a);
    c.bindTo("floors", a);
    c.bindTo("floorId", a);
    return b;
  };
  bM = function (a) {
    a.Pg[1] = !0;
    _.Om(a.Rg);
  };
  mMa = function (a) {
    if (!a.Og && !a.Jh && a.Fi && a.Eg) {
      var b = (a.Og = new FMa(
        a.Eg,
        a.Fi,
        a.di,
        a.Lg,
        a.dj,
        a.rj,
        a.Kg,
        a.si,
        a.sj || void 0,
        a.Tg
      ));
      b.bindTo("mapHeading", a, "heading");
      b.bindTo("tilt", a);
      b.bindTo("projection", a.Eg);
      b.bindTo("mapTypeId", a);
      a.bindTo("panoramaVisible", b);
      b.bindTo("mapSize", a, "size");
      b.bindTo("display", a, "streetViewControl");
      b.bindTo("disableDefaultUI", a);
      (b = a.Eg.__gm.Jg) && b.__gm.set("focusFallbackElement", a.di);
      GMa(a);
    }
  };
  GMa = function (a) {
    const b = a.Og;
    if (b) {
      var c = b.Lg,
        d = a.get("streetView");
      if (d != c) {
        if (c) {
          const e = c.__gm;
          e.unbind("result");
          e.unbind("heading");
          c.unbind("passiveLogo");
          c.Eg.removeListener(a.lj, a);
          c.Eg.set(!1);
        }
        d &&
          ((c = d.__gm),
          c.get("result") != null && b.set("result", c.get("result")),
          c.bindTo("isHover", b),
          c.bindTo("result", b),
          c.get("heading") != null && b.set("heading", c.get("heading")),
          c.bindTo("heading", b),
          d.bindTo("passiveLogo", a),
          d.Eg.addListener(a.lj, a),
          a.set("panoramaVisible", d.get("visible")),
          b.bindTo("client", d));
        b.Lg = d;
      }
    }
  };
  _.IMa = function (a, b) {
    const c = document.createElement("div");
    var d = c.style;
    d.backgroundColor = "white";
    d.fontWeight = "500";
    d.fontFamily = "Roboto, sans-serif";
    d.padding = "15px 25px";
    d.boxSizing = "border-box";
    d.top = "5px";
    d = document.createElement("div");
    var e = document.createElement("img");
    e.alt = "";
    e.src = _.ay + "api-3/images/google_gray.svg";
    e.style.border = e.style.margin = e.style.padding = 0;
    e.style.height = "17px";
    e.style.verticalAlign = "middle";
    e.style.width = "52px";
    _.Ks(e);
    d.appendChild(e);
    c.appendChild(d);
    d = document.createElement("div");
    d.style.lineHeight = "20px";
    d.style.margin = "15px 0";
    e = document.createElement("span");
    e.style.color = "rgba(0,0,0,0.87)";
    e.style.fontSize = "14px";
    e.innerText =
      "Trang n\u00e0y kh\u00f4ng th\u1ec3 t\u1ea3i Google Maps \u0111\u00fang c\u00e1ch.";
    d.appendChild(e);
    c.appendChild(d);
    d = document.createElement("table");
    d.style.width = "100%";
    e = document.createElement("tr");
    var f = document.createElement("td");
    f.style.lineHeight = "16px";
    f.style.verticalAlign = "middle";
    const g = document.createElement("a");
    _.Ar(g, b);
    g.innerText =
      "B\u1ea1n c\u00f3 s\u1edf h\u1eefu trang web n\u00e0y kh\u00f4ng?";
    g.target = "_blank";
    g.setAttribute("rel", "noopener");
    g.style.color = "rgba(0, 0, 0, 0.54)";
    g.style.fontSize = "12px";
    g.onclick = () => {
      _.pl(a, "Dl");
      _.M(a, 148243);
    };
    f.appendChild(g);
    e.appendChild(f);
    _.xq(HMa);
    b = document.createElement("td");
    b.style.textAlign = "right";
    f = document.createElement("button");
    f.className = "dismissButton";
    f.innerText = "OK";
    f.onclick = () => {
      a.removeChild(c);
      _.Ek(a, "dmd");
      _.pl(a, "Dd");
      _.M(a, 148242);
    };
    b.appendChild(f);
    e.appendChild(b);
    d.appendChild(e);
    c.appendChild(d);
    a.appendChild(c);
    _.pl(a, "D0");
    _.M(a, 148244);
    return c;
  };
  KMa = function (a, b, c, d, e, f, g, h, k, m, p, t, u, w, x, z, B, C) {
    var F = b.get("streetView");
    k = b.__gm;
    if (F && k) {
      t = new _.NK(_.YC(), F.get("client"));
      F = _.Hda[F.get("client")];
      var I = new JMa({
          lH: function (D) {
            return u.fromContainerPixelToLatLng(new _.vl(D.clientX, D.clientY));
          },
          UC: b.controls,
          Hr: m,
          Ck: p,
          bE: a,
          map: b,
          mv: b.mapTypes,
          Lp: d,
          XE: !0,
          ah: w,
          controlSize: b.get("controlSize") || 40,
          nL: F,
          fF: t,
          Ur: x,
          gp: z,
          fp: B,
          QH: !0,
          Ai: C,
        }),
        T = new _.hK(["bounds"], "bottomRight", (D) => D && _.Xq(D)),
        V,
        qa;
      _.Ck(b, "idle", () => {
        var D = b.get("bounds");
        D != V && (I.set("bounds", D), T.set("bounds", D), (V = D));
        D = b.get("center");
        D != qa && (I.set("center", D), (qa = D));
      });
      I.bindTo("bottomRight", T);
      I.bindTo("disableDefaultUI", b);
      I.bindTo("heading", b);
      I.bindTo("projection", b);
      I.bindTo("reportErrorControl", b);
      I.bindTo("restriction", b);
      I.bindTo("passiveLogo", b);
      I.bindTo("zoom", k);
      I.bindTo("mapTypeId", c);
      I.bindTo("attributionText", e);
      I.bindTo("zoomRange", g);
      I.bindTo("aerialAvailableAtZoom", h);
      I.bindTo("tilt", h);
      I.bindTo("desiredTilt", h);
      I.bindTo("keyboardShortcuts", b, "keyboardShortcuts", !0);
      I.bindTo("cameraControlOptions", b, null, !0);
      I.bindTo("mapTypeControlOptions", b, null, !0);
      I.bindTo("panControlOptions", b, null, !0);
      I.bindTo("rotateControlOptions", b, null, !0);
      I.bindTo("scaleControlOptions", b, null, !0);
      I.bindTo("streetViewControlOptions", b, null, !0);
      I.bindTo("zoomControlOptions", b, null, !0);
      I.bindTo("mapTypeControl", b);
      I.bindTo("myLocationControlOptions", b);
      I.bindTo("fullscreenControlOptions", b, null, !0);
      b.get("fullscreenControlOptions") && I.notify("fullscreenControlOptions");
      I.bindTo("cameraControl", b);
      I.bindTo("panControl", b);
      I.bindTo("rotateControl", b);
      I.bindTo("motionTrackingControl", b);
      I.bindTo("motionTrackingControlOptions", b, null, !0);
      I.bindTo("scaleControl", b);
      I.bindTo("streetViewControl", b);
      I.bindTo("fullscreenControl", b);
      I.bindTo("zoomControl", b);
      I.bindTo("myLocationControl", b);
      I.bindTo("rmiAvailable", f, "available");
      I.bindTo("streetView", b);
      I.bindTo("fontLoaded", k);
      I.bindTo("size", k);
      k.bindTo("renderHeading", I);
      _.Dk(I, "panbyfraction", k);
    }
  };
  LMa = function (a, b, c, d, e, f, g, h) {
    const k = new _.NK(_.YC(), g.get("client")),
      m = new JMa({
        UC: f,
        Hr: d,
        Ai: !0,
        Ck: h,
        bE: e,
        Lp: c,
        controlSize: g.get("controlSize") || 40,
        XE: !1,
        oL: g,
        fF: k,
      });
    m.set("streetViewControl", !1);
    m.bindTo("attributionText", b, "copyright");
    m.set("mapTypeId", "streetview");
    m.set("tilt", !0);
    m.bindTo("heading", b);
    m.bindTo("zoom", b, "zoomFinal");
    m.bindTo("zoomRange", b);
    m.bindTo("pov", b, "pov");
    m.bindTo("position", g);
    m.bindTo("pano", g);
    m.bindTo("passiveLogo", g);
    m.bindTo("floors", b);
    m.bindTo("floorId", b);
    m.bindTo("rmiWidth", g);
    m.bindTo("fullscreenControlOptions", g, null, !0);
    m.bindTo("panControlOptions", g, null, !0);
    m.bindTo("zoomControlOptions", g, null, !0);
    m.bindTo("fullscreenControl", g);
    m.bindTo("panControl", g);
    m.bindTo("zoomControl", g);
    m.bindTo("disableDefaultUI", g);
    m.bindTo("fontLoaded", g.__gm);
    m.bindTo("size", b);
    a.view &&
      a.view.addListener("scene_changed", () => {
        const p = a.view.get("scene");
        m.set("isCustomPanorama", p === "c");
      });
    _.Pm(m.Rg);
    _.Dk(m, "panbyfraction", a);
  };
  eM = function (a, b) {
    _.M(window, a);
    _.pl(window, b);
  };
  MMa = function (a) {
    const b = a.get("zoom");
    _.xj(b) && (a.set("zoom", b + 1), eM(165374, "Zmki"));
  };
  NMa = function (a) {
    const b = a.get("zoom");
    _.xj(b) && (a.set("zoom", b - 1), eM(165374, "Zmki"));
  };
  fM = function (a, b, c) {
    _.Ek(a, "panbyfraction", b, c);
    eM(165373, "Pmki");
  };
  OMa = function (a, b) {
    return !!(
      b.target !== a.src ||
      b.ctrlKey ||
      b.altKey ||
      b.metaKey ||
      a.get("enabled") === !1
    );
  };
  RMa = function (a, b, c, d, e, f) {
    const g = new PMa(b, e, f);
    g.bindTo("zoom", a);
    g.bindTo("enabled", a, "keyboardShortcuts");
    e && g.bindTo("tilt", a.__gm);
    f && g.bindTo("heading", a);
    _.Dk(g, "tiltrotatebynow", a.__gm);
    _.Dk(g, "panbyfraction", a.__gm);
    _.Dk(g, "panbynow", a.__gm);
    _.Dk(g, "panby", a.__gm);
    QMa(a, d, e, f);
    const h = a.__gm.Jg;
    let k = null;
    _.Ck(a, "streetview_changed", () => {
      const m = a.get("streetView"),
        p = k;
      p && _.uk(p);
      k = null;
      m &&
        (k = _.Ck(m, "visible_changed", () => {
          m.getVisible() && m === h
            ? (b.blur(), (c.style.visibility = "hidden"))
            : (c.style.visibility = "");
        }));
    });
    d = () => {
      g.Rg = !!a.get("headingInteractionEnabled");
      g.Sg = !!a.get("tiltInteractionEnabled");
    };
    _.Ck(a, "tiltinteractionenabled_changed", d);
    _.Ck(a, "headinginteractionenabled_changed", d);
  };
  QMa = function (a, b, c, d) {
    const e = new _.LK({ fp: d, gp: c, ownerElement: b, Rv: !1, Js: "map" });
    _.Ck(a, "keyboardshortcuts_changed", () => {
      _.hr(a) ? b.append(e.element) : e.element.remove();
    });
  };
  SMa = () => _.Kha.some((a) => !!document[a]);
  QJa = {};
  UJa = class extends _.Hk {
    constructor(a, b, c, d, e, f, g) {
      super();
      this.label = a || "";
      this.alt = b || "";
      this.Ig = f || null;
      this.Sn = c;
      this.Eg = d;
      this.Hg = e;
      this.Fg = g || null;
    }
  };
  var uMa = class extends _.Hk {
    constructor(a, b) {
      super();
      this.Ig = a;
      this.mapping = {};
      this.buttons = [];
      this.Fg = this.Hg = this.Eg = null;
      b = b || ["roadmap", "satellite", "hybrid", "terrain"];
      const c = _.Mb(b, "terrain") && _.Mb(b, "roadmap"),
        d = _.Mb(b, "hybrid") && _.Mb(b, "satellite");
      _.sk(this, "maptypeid_changed", () => {
        const e = this.get("mapTypeId");
        this.Fg && this.Fg.set("display", e === "satellite");
        this.Eg && this.Eg.set("display", e === "roadmap");
      });
      _.sk(this, "zoom_changed", () => {
        if (this.Eg) {
          const e = this.get("zoom");
          this.Eg.set("enabled", e <= this.Hg);
        }
      });
      for (const e of b) {
        if (e === "hybrid" && d) continue;
        if (e === "terrain" && c) continue;
        b = a.get(e);
        if (!b) continue;
        let f = null;
        e === "roadmap"
          ? c &&
            ((this.Eg = SJa(
              this,
              "terrain",
              "roadmap",
              "terrain",
              void 0,
              "Thu nh\u1ecf \u0111\u1ec3 hi\u1ec3n th\u1ecb b\u1ea3n \u0111\u1ed3 ph\u1ed1 c\u00f3 \u0111\u1ecba h\u00ecnh"
            )),
            (f = [[this.Eg]]),
            (this.Hg = a.get("terrain").maxZoom))
          : (e !== "satellite" && e !== "hybrid") ||
            !d ||
            ((this.Fg = TJa(this)), (f = [[this.Fg]]));
        this.buttons.push(
          new UJa(b.name, b.alt, "mapTypeId", e, null, null, f)
        );
      }
    }
  };
  var gM = (0,
  _.Tf)`.gm-control-active\u003eimg{-webkit-box-sizing:content-box;box-sizing:content-box;display:none;left:50%;pointer-events:none;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.gm-control-active\u003eimg:nth-child(1){display:block}.gm-control-active:focus\u003eimg:nth-child(1),.gm-control-active:hover\u003eimg:nth-child(1),.gm-control-active:active\u003eimg:nth-child(1),.gm-control-active:disabled\u003eimg:nth-child(1){display:none}.gm-control-active:focus\u003eimg:nth-child(2),.gm-control-active:hover\u003eimg:nth-child(2){display:block}.gm-control-active:active\u003eimg:nth-child(3){display:block}.gm-control-active:disabled\u003eimg:nth-child(4){display:block}sentinel{}\n`;
  var BMa = class extends HTMLElement {
    constructor(a = { controlSize: 40, av: !1 }) {
      super();
      this.Fg = this.Qg = !1;
      this.Hg = _.eu(
        "C\u00e1c ch\u1ebf \u0111\u1ed9 \u0111i\u1ec1u khi\u1ec3n camera tr\u00ean b\u1ea3n \u0111\u1ed3"
      );
      this.Eg = document.createElement("menu");
      this.Ig = 1;
      this.controlSize = a.controlSize;
      this.av = a.av || !1;
      this.yp = a.yp;
      this.Og = wL(this, "Up");
      this.Kg = wL(this, "Left");
      this.Lg = wL(this, "Right");
      this.Jg = wL(this, "Down");
      this.Pg = XJa(this, 0);
      this.Ug = XJa(this, 1);
    }
    connectedCallback() {
      if (!this.Qg) {
        this.Qg = !0;
        this.style.cursor = "pointer";
        this.dataset.controlWidth = String(this.controlSize);
        this.dataset.controlHeight = String(this.controlSize);
        _.Ls(this);
        _.Ks(this);
        _.nL(this);
        _.yq(gM, this.yp || this);
        uL(this, this.Hg);
        const a = this.Ig === 2 ? "_dark" : "";
        yL(
          this,
          [
            _.fy[`camera_control${a}.svg`],
            _.fy[`camera_control_hover${a}.svg`],
            _.fy[`camera_control_active${a}.svg`],
            _.fy[`camera_control_disable${a}.svg`],
          ],
          this.Hg
        );
        this.Hg.type = "button";
        this.Hg.setAttribute("aria-expanded", "false");
        YJa(this);
        this.appendChild(this.Hg);
        this.appendChild(this.Eg);
        this.Hg.setAttribute("aria-controls", this.Eg.id);
        ZJa(this);
      }
    }
    Vg(a) {
      const b = this.controlSize >> 2;
      a = a.Yg;
      if (
        Number((a.style.left || a.style.right).replace("px", "")) >
        this.controlSize
      )
        (this.Eg.style.left = `-${this.controlSize + 2 * b}px`),
          a.style.bottom
            ? (this.Eg.style.bottom = "100%")
            : (this.Eg.style.top = "100%");
      else {
        this.av
          ? (this.Eg.style.left = "100%")
          : (this.Eg.style.right = "100%");
        var c = window.getComputedStyle(a),
          d = Number(c.bottom.replace("px", ""));
        c = Number(c.top.replace("px", ""));
        var e = Number(this.style.top.replace("px", ""));
        a.style.top
          ? (this.Eg.style.top =
              c + e >= this.controlSize + b
                ? `-${this.controlSize + 2 * b}px`
                : `-${b}px`)
          : d - e - this.controlSize >= this.controlSize + b
          ? (this.Eg.style.top = `-${this.controlSize + 2 * b}px`)
          : (this.Eg.style.bottom = `-${b}px`);
      }
    }
    Sg(a, b, c, d) {
      if (d) {
        var e = c.toJSON(),
          f = d.latLngBounds.toJSON();
        d = e.north >= f.north - 1e-6;
        c = e.west <= f.west + 1e-6;
        const g = e.east >= f.east - 1e-6;
        e = e.south <= f.south + 1e-6;
        f = this.getRootNode().activeElement;
        ((f === this.Og && d) ||
          (f === this.Kg && c) ||
          (f === this.Lg && g) ||
          (f === this.Jg && e)) &&
          this.Hg.focus();
        this.Og.disabled = d;
        this.Kg.disabled = c;
        this.Lg.disabled = g;
        this.Jg.disabled = e;
      }
      WJa(a, b, this.Pg, this.Ug);
    }
    Tg(a) {
      a = (a !== "satellite" && a !== "hybrid") || !_.an[43] ? 1 : 2;
      if (this.Ig !== a) {
        this.Ig = a;
        var b = a === 2 ? "_dark" : "";
        yL(
          this,
          [
            _.fy[`camera_control${b}.svg`],
            _.fy[`camera_control_hover${b}.svg`],
            _.fy[`camera_control_active${b}.svg`],
            _.fy[`camera_control_disable${b}.svg`],
          ],
          this.Hg
        );
        vL(this, this.Jg, "Down");
        vL(this, this.Kg, "Left");
        vL(this, this.Lg, "Right");
        vL(this, this.Og, "Up");
        tL(this.Pg, 0, a, this.controlSize);
        tL(this.Pg, 1, a, this.controlSize);
      }
    }
    Rg(a, b) {
      this.style.display =
        (b && b.width >= 200 && b.height >= 200) || a ? "" : "none";
    }
  };
  _.Sl("gmp-internal-camera-control", BMa);
  var aMa = class extends _.Hk {
    constructor(a) {
      super();
      this.Yg = a;
      this.Eg = null;
    }
    card_changed() {
      const a = this.get("card");
      this.Eg && this.Yg.removeChild(this.Eg);
      if (a) {
        const b = (this.Eg = _.Is("div"));
        b.style.backgroundColor = "white";
        b.appendChild(a);
        b.style.margin = _.ds(10);
        b.style.padding = _.ds(1);
        b.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
        b.style.borderRadius = _.ds(2);
        this.Yg.appendChild(b);
        this.Eg = b;
      } else this.Eg = null;
    }
    getDiv() {
      return this.Yg;
    }
  };
  var TMa = class extends _.W {
    constructor() {
      super();
    }
    getHeading() {
      return _.Vi(this.Gg, 1);
    }
    setHeading(a) {
      _.Xr(this.Gg, 1, a);
    }
  };
  var zL = {},
    AL = null;
  _.Ia(CL, _.mg);
  CL.prototype.Bn = function (a) {
    this.dispatchEvent(a);
  };
  _.Ia(DL, CL);
  _.G = DL.prototype;
  _.G.xj = function () {
    return this.duration;
  };
  _.G.stop = function (a) {
    BL(this);
    this.Eg = 0;
    a && (this.progress = 1);
    dKa(this, this.progress);
    this.Bn("stop");
    this.Bn("end");
  };
  _.G.pause = function () {
    this.Eg == 1 && (BL(this), (this.Eg = -1), this.Bn("pause"));
  };
  _.G.kj = function () {
    this.Eg == 0 || this.stop(!1);
    this.Bn("destroy");
    DL.Wn.kj.call(this);
  };
  _.G.destroy = function () {
    this.dispose();
  };
  _.G.Bn = function (a) {
    this.dispatchEvent(new eKa(a, this));
  };
  _.Ia(eKa, _.Xf);
  var CMa = class extends _.Hk {
    constructor(a, b, c) {
      super();
      this.layout = a;
      this.animation = null;
      this.Eg = !1;
      b /= 40;
      a.mh.style.transform = `scale(${b})`;
      a.mh.style.transformOrigin = "left";
      a.mh.dataset.controlWidth = String(Math.round(48 * b));
      a.mh.dataset.controlHeight = String(Math.round(48 * b));
      a.addListener("compass.clockwise", "click", (d) => {
        hKa(this, d, !0);
      });
      a.addListener("compass.counterclockwise", "click", (d) => {
        hKa(this, d, !1);
      });
      a.addListener("compass.north", "click", (d) => {
        const e = this.get("pov");
        if (e) {
          var f = _.Yr(e.heading, 360);
          this.startAnimation(f, f < 180 ? 0 : 360, e.pitch, 0);
          gKa(d);
        }
      });
      _.yq(gM, c);
    }
    changed() {
      !this.Eg &&
        this.animation &&
        (this.animation.stop(), (this.animation = null));
      const a = this.get("pov");
      if (a) {
        var b = new TMa();
        b.setHeading(_.vj(-a.heading, 0, 360));
        _.Tr(_.Hi(b.Gg, 3, _.EG), _.FG(_.MD(_.fy["compass_background.svg"])));
        _.Tr(
          _.Hi(b.Gg, 4, _.EG),
          _.FG(_.MD(_.fy["compass_needle_normal.svg"]))
        );
        _.Tr(_.Hi(b.Gg, 5, _.EG), _.FG(_.MD(_.fy["compass_needle_hover.svg"])));
        _.Tr(
          _.Hi(b.Gg, 6, _.EG),
          _.FG(_.MD(_.fy["compass_needle_active.svg"]))
        );
        _.Tr(
          _.Hi(b.Gg, 7, _.EG),
          _.FG(_.MD(_.fy["compass_rotate_normal.svg"]))
        );
        _.Tr(_.Hi(b.Gg, 8, _.EG), _.FG(_.MD(_.fy["compass_rotate_hover.svg"])));
        _.Tr(
          _.Hi(b.Gg, 9, _.EG),
          _.FG(_.MD(_.fy["compass_rotate_active.svg"]))
        );
        _.Xg(
          b.Gg,
          10,
          "Xoay ng\u01b0\u1ee3c chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3"
        );
        _.Xg(b.Gg, 11, "Xoay theo chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3");
        _.Xg(b.Gg, 12, "\u0110\u1eb7t l\u1ea1i ch\u1ebf \u0111\u1ed9 xem");
        this.layout.update([b]);
        this.layout.mh.style.setProperty(
          "--gm-compass-control-rotation-degree",
          `rotate(${b.getHeading()}deg)`
        );
      }
    }
    mapSize_changed() {
      EL(this);
    }
    disableDefaultUI_changed() {
      EL(this);
    }
    panControl_changed() {
      EL(this);
    }
    startAnimation(a, b, c, d) {
      const e = new _.Nq();
      this.animation && this.animation.stop();
      a = this.animation = new DL([a, c], [b, d], 1200, fKa);
      JJa(e, a, (f) => {
        iKa(this, !1, f);
      });
      _.Lxa(e, a, "finish", (f) => {
        iKa(this, !0, f);
      });
      cKa(a);
    }
  };
  var ULa = class extends _.Hk {
      constructor(a, b, c, d, e = 1) {
        super();
        this.Il = c;
        this.Jg = [];
        this.set("colorTheme", e);
        this.Kg = e;
        this.Hg = a;
        this.Ig = d;
        this.Eg = b;
        this.Eg.style.cursor = "pointer";
        this.Eg.setAttribute("aria-pressed", "false");
        this.Fg = SMa();
        this.Lg = () => {
          this.Il.set(_.Kda(this.Hg));
        };
        this.refresh = () => {
          let f = this.get("display");
          const g = !!this.get("disableDefaultUI");
          _.pE(this.Eg, ((f === void 0 && !g) || !!f) && this.Fg);
          _.Ek(this.Eg, "resize");
        };
        this.Fg &&
          (_.yq(gM, a),
          this.Eg.setAttribute(
            "class",
            "gm-control-active gm-fullscreen-control"
          ),
          (this.Eg.style.borderRadius = _.ds(_.CG(d))),
          (this.Eg.style.width = this.Eg.style.height = _.ds(d)),
          (this.Eg.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)"),
          FL(this.Eg, this.Il.get(), d, e),
          (this.Eg.style.overflow = "hidden"),
          _.yk(this.Eg, "click", (f) => {
            const g = _.uE(f) ? 164676 : 164675;
            _.pl(window, _.uE(f) ? "Fscmi" : "Fscki");
            _.M(window, g);
            if (this.Il.get()) {
              for (const h of _.Iha)
                if (h in document) {
                  document[h]();
                  break;
                }
              this.Eg.setAttribute("aria-pressed", "false");
            } else {
              for (const h of _.Jha) this.Jg.push(_.yk(document, h, this.Lg));
              f = this.Hg;
              for (const h of _.Lha)
                if (h in f) {
                  f[h]();
                  break;
                }
              this.Eg.setAttribute("aria-pressed", "true");
            }
          }));
        _.sk(this, "disabledefaultui_changed", this.refresh);
        _.sk(this, "display_changed", this.refresh);
        _.sk(this, "maptypeid_changed", () => {
          const f =
            this.get("mapTypeId") == "streetview" ? 2 : this.get("colorTheme");
          GL(this, f);
          this.Eg.style.margin = _.ds(this.Ig >> 2);
          this.refresh();
        });
        _.sk(this, "colorTheme_changed", () => {
          let f = this.get("colorTheme");
          f == null && (f = 1);
          GL(this, f);
        });
        this.Il.addListener(() => {
          _.Ek(this.Hg, "resize");
          this.Il.get() || jKa(this);
          this.Fg && FL(this.Eg, this.Il.get(), this.Ig, this.Kg);
        });
        GL(this, e);
        this.refresh();
      }
    },
    kKa = {
      [1]: { kI: -52, close: -78, top: -86, backgroundColor: "#fff" },
      [2]: { kI: 0, close: -26, top: -86, backgroundColor: "#444" },
    };
  var lKa = (0,
  _.Tf)`.gm-style .gm-style-cc a,.gm-style .gm-style-cc button,.gm-style .gm-style-cc span,.gm-style .gm-style-mtc div{font-size:10px;-webkit-box-sizing:border-box;box-sizing:border-box}.gm-style .gm-style-cc a,.gm-style .gm-style-cc button,.gm-style .gm-style-cc span{outline-offset:3px}sentinel{}\n`;
  var UMa = class extends _.Hk {
    constructor(a, b, c) {
      super();
      this.Yg = a;
      _.nL(a);
      _.Js(a, 1000001);
      this.Fg = c;
      this.Jg = _.Is("div", a);
      this.Hg = _.HL(this.Jg, b, c);
      a = _.eu("Ph\u00edm t\u1eaft");
      this.Hg.appendChild(a);
      a.textContent = "Ph\u00edm t\u1eaft";
      a.style.color = this.Fg ? "#fff" : "#000000";
      a.style.display = "inline-block";
      a.style.fontFamily = "inherit";
      a.style.lineHeight = "inherit";
      _.mE(a, "click", this);
      this.Eg = a;
      a = new Image();
      a.src = this.Fg
        ? _.fy["keyboard_icon_dark.svg"]
        : _.fy["keyboard_icon.svg"];
      a.alt = "";
      a.style.height = "9px";
      a.style.verticalAlign = "-1px";
      this.Ig = a;
      JL(this);
    }
    async fontLoaded_changed() {
      await JL(this);
    }
    keyboardShortcutsShown_changed() {
      JL(this);
    }
    Sq() {
      this.get("keyboardShortcutsShown") &&
        ((this.Yg.style.display = ""),
        (this.Eg.textContent = ""),
        this.Eg.appendChild(this.Ig),
        _.zE(),
        _.Ek(this, "update"));
    }
    Rq() {
      this.get("keyboardShortcutsShown") &&
        ((this.Yg.style.display = ""),
        (this.Eg.textContent = ""),
        (this.Eg.textContent = "Ph\u00edm t\u1eaft"),
        _.zE(),
        _.Ek(this, "update"));
    }
    Kj() {
      this.get("keyboardShortcutsShown") ||
        ((this.Yg.style.display = "none"), _.Ek(this, "update"));
    }
    Fl() {
      return this.Yg;
    }
    SD() {
      return this.Fg;
    }
  };
  var XLa = class extends _.Hk {
    constructor(a, b) {
      super();
      this.Fg = a;
      this.Hg = b;
      this.Yg = _.Is("div");
      this.element = mKa(this);
      this.Eg = document.activeElement === this.element;
      nKa(this);
      _.yk(this.element, "focus", () => {
        this.Sz();
      });
      _.yk(this.element, "blur", () => {
        this.Eg = !1;
        nKa(this);
      });
      _.sk(this, "update", () => {
        this.Eg && oKa(this);
      });
      _.Dk(a, "update", this);
    }
    Sz() {
      this.Eg = !0;
      oKa(this);
    }
  };
  var VMa = new Set([3, 12, 6, 9]),
    WMa = [1, 2, 3, 5, 7, 4, 13, 8, 6, 9, 10, 11, 12],
    XMa = [3, 2, 1, 7, 5, 8, 13, 4, 9, 6, 12, 11, 10],
    YMa = new Set([24, 23, 25, 19, 17, 18, 22, 21, 20, 15, 14, 16]),
    $Ma = class extends _.Hk {
      constructor(a, b = !1) {
        super();
        this.Ig = a;
        this.Jg = new _.Nm(() => this.Kg(), 0);
        _.hs(a, "resize", this, this.Kg);
        this.Hg = new Map();
        this.Fg = new Set();
        this.set("isRTL", b);
        this.Eg = new Map();
        for (const c of WMa)
          (a = document.createElement("div")),
            this.Ig.appendChild(a),
            this.Eg.set(c, a),
            this.Hg.set(c, []);
        this.isRTL_changed();
      }
      getSize() {
        return _.en(this.Ig);
      }
      addElement(a, b, c = !1, d) {
        var e = ML(this, b);
        const f = this.Hg.get(e);
        if (f) {
          [...this.Fg].some((k) => k.element === a);
          var g = d !== void 0 && _.xj(d) ? d : f.length,
            h;
          for (
            h = 0;
            h < f.length &&
            !(f[h].index === g && f[h].RD < b) &&
            !(f[h].index > g);
            ++h
          );
          b = {
            element: a,
            xv: !!c,
            index: g,
            bJ: d,
            RD: b,
            listener: _.sk(a, "resize", () => _.Om(this.Jg)),
          };
          f.splice(h, 0, b);
          this.Fg.add(b);
          _.Gs(a);
          a.style.visibility = "hidden";
          b = this.Eg.get(e);
          e = this.get("isRTL") ^ VMa.has(e) ? f.length - h - 1 : h;
          b.insertBefore(a, b.children[e]);
          _.Om(this.Jg);
        }
      }
      nl(a) {
        a.parentNode && a.parentNode.removeChild(a);
        for (const c of this.Hg.values())
          for (let d = 0; d < c.length; ++d)
            if (c[d].element === a) {
              this.Fg.delete(c[d]);
              var b = a;
              b.style.top = "auto";
              b.style.bottom = "auto";
              b.style.left = "auto";
              b.style.right = "auto";
              _.uk(c[d].listener);
              c.splice(d, 1);
            }
        _.Om(this.Jg);
      }
      Kg() {
        var a = this.getSize();
        const b = a.width;
        a = a.height;
        var c = this.Hg,
          d = [];
        const e = hM(c.get(1), "left", "top", d),
          f = iM(c.get(5), "left", "top", d);
        d = [];
        const g = hM(c.get(10), "left", "bottom", d),
          h = iM(c.get(6), "left", "bottom", d);
        d = [];
        const k = hM(c.get(3), "right", "top", d),
          m = iM(c.get(7), "right", "top", d);
        d = [];
        const p = hM(c.get(12), "right", "bottom", d);
        d = iM(c.get(9), "right", "bottom", d);
        const t = ZMa(c.get(11), "bottom", b),
          u = ZMa(c.get(2), "top", b),
          w = jM(c.get(4), "left", b, a);
        jM(c.get(13), "center", b, a);
        c = jM(c.get(8), "right", b, a);
        this.set(
          "bounds",
          new _.km([
            new _.vl(
              Math.max(w, e.width, g.width, f.width, h.width) || 0,
              Math.max(u, e.height, f.height, k.height, m.height) || 0
            ),
            new _.vl(
              b - (Math.max(c, k.width, p.width, m.width, d.width) || 0),
              a - (Math.max(t, g.height, p.height, h.height, d.height) || 0)
            ),
          ])
        );
      }
      isRTL_changed() {
        if (this.Eg) {
          var a = this.get("isRTL") ? XMa : WMa;
          for (const b of a) this.Ig.appendChild(this.Eg.get(b));
          a = [...this.Fg];
          for (const b of a)
            this.nl(b.element), this.addElement(b.element, b.RD, b.xv, b.bJ);
        }
      }
    },
    aNa = (a) => {
      let b = 0;
      for (var { height: c } of a) b = Math.max(c, b);
      let d = (c = 0);
      for (let e = a.length; e > 0; --e) {
        const f = a[e - 1];
        if (b === f.height) {
          f.width > d && f.width > f.height ? (d = f.height) : (c = f.width);
          break;
        } else d = Math.max(f.height, d);
      }
      return new _.xl(c, d);
    },
    hM = (a, b, c, d) => {
      let e = 0,
        f = 0;
      const g = [];
      for (const { xv: k, element: m } of a) {
        var h = KL(m);
        const p = KL(m, !0);
        a = LL(m);
        const t = LL(m, !0);
        m.style[b] = _.ds(b === "left" ? e : e + (h - p));
        m.style[c] = _.ds(c === "top" ? 0 : a - t);
        h = e + h;
        a > f && ((f = a), d.push({ minWidth: e, height: f }));
        e = h;
        k || g.push(new _.xl(e, a));
        m.style.visibility = "";
      }
      return aNa(g);
    },
    iM = (a, b, c, d) => {
      var e = 0;
      const f = [];
      for (const { xv: g, element: h } of a) {
        a = KL(h);
        const k = LL(h),
          m = KL(h, !0),
          p = LL(h, !0);
        let t = 0;
        for (const { height: u, minWidth: w } of d) {
          if (w > a) break;
          t = u;
        }
        e = Math.max(t, e);
        h.style[c] = _.ds(c === "top" ? e : e + k - p);
        h.style[b] = _.ds(b === "left" ? 0 : a - m);
        e += k;
        g || f.push(new _.xl(a, e));
        h.style.visibility = "";
      }
      return aNa(f);
    },
    jM = (a, b, c, d) => {
      let e = 0,
        f = 0;
      for (const { xv: g, element: h } of a) {
        const k = KL(h),
          m = LL(h),
          p = KL(h, !0);
        b === "left"
          ? (h.style.left = "0")
          : b === "right"
          ? (h.style.right = _.ds(k - p))
          : (h.style.left = _.ds((c - p) / 2));
        e += m;
        g || (f = Math.max(k, f));
      }
      b = (d - e) / 2;
      for (const { element: g } of a)
        (g.style.top = _.ds(b)), (b += LL(g)), (g.style.visibility = "");
      return f;
    },
    ZMa = (a, b, c) => {
      let d = 0,
        e = 0;
      for (const { xv: f, element: g } of a) {
        const h = KL(g),
          k = LL(g),
          m = LL(g, !0);
        g.style[b] = _.ds(b === "top" ? 0 : k - m);
        d += h;
        f || (e = Math.max(k, e));
      }
      b = (c - d) / 2;
      for (const { element: f } of a)
        (f.style.left = _.ds(b)), (b += KL(f)), (f.style.visibility = "");
      return e;
    };
  var kMa = class {
    constructor(a, b, c = 0) {
      this.Yg = a;
      this.padding = c;
      this.elements = [];
      YMa.has(b);
      this.Fg = (this.Eg = b === 3 || b === 12 || b === 6 || b === 9)
        ? KJa.bind(this)
        : _.Kb.bind(this);
      a.dataset.controlWidth = "0";
      a.dataset.controlHeight = "0";
    }
    add(a) {
      a.style.position = "absolute";
      this.Eg
        ? this.Yg.insertBefore(a, this.Yg.firstChild)
        : this.Yg.appendChild(a);
      a = qKa(this, a);
      this.elements.push(a);
      NL(this, a);
    }
    remove(a) {
      this.Yg.removeChild(a);
      KJa(this.elements, (b, c) => {
        b.element === a && (this.elements.splice(c, 1), this.onRemove(b));
      });
    }
    onRemove(a) {
      a && (NL(this, a), a.fB && (_.uk(a.fB), delete a.fB));
    }
  };
  _.Yn("api-3/images/my_location_spinner", !0, !0);
  var tKa = class {
    constructor(a, b, c) {
      this.Ig = a;
      this.Jg = c;
      this.Fg = _.Is("div");
      this.Fg.style.margin = "0 5px";
      this.Fg.style.zIndex = 1e6;
      this.Eg = _.Is("a");
      this.Eg.style.display = "inline";
      this.Eg.target = "_blank";
      this.Eg.rel = "noopener";
      this.Eg.title =
        "M\u1edf khu v\u1ef1c n\u00e0y trong Google Maps (m\u1edf c\u1eeda s\u1ed5 m\u1edbi)";
      this.Eg.setAttribute(
        "aria-label",
        "M\u1edf khu v\u1ef1c n\u00e0y trong Google Maps (m\u1edf c\u1eeda s\u1ed5 m\u1edbi)"
      );
      _.Ar(this.Eg, _.MD(b.get("url")));
      this.Eg.addEventListener("click", (d) => {
        const e = _.uE(d) ? 165230 : 165229;
        _.pl(window, _.uE(d) ? "Lcmi" : "Lcki");
        _.M(window, e);
      });
      this.Hg = _.Is("div");
      _.dn(this.Hg, _.dq);
      _.Ls(this.Hg);
      this.Mg = _.KG(null, this.Hg, _.Jl, _.dq);
      this.Mg.alt = "Google";
      _.sk(b, "url_changed", () => {
        _.Ar(this.Eg, _.MD(b.get("url")));
      });
      _.sk(this.Ig, "passivelogo_changed", () => {
        vKa(this);
      });
      vKa(this);
    }
    getDiv() {
      return this.Fg;
    }
  };
  var QL = class extends _.Hk {
    constructor(a, b, c) {
      super();
      _.sk(this, "value_changed", () => {
        this.set("active", this.get("value") == b);
      });
      const d = () => {
        this.get("enabled") !== !1 &&
          (c != null && this.get("active")
            ? this.set("value", c)
            : this.set("value", b));
      };
      new _.Vm(a, "click", d);
      a.tagName.toLowerCase() !== "button" &&
        new _.Vm(a, "keydown", (e) => {
          (e.key !== "Enter" && e.key !== " ") || d();
        });
      _.sk(this, "display_changed", () => {
        _.pE(a, this.get("display") !== !1);
      });
    }
  };
  var wKa = class extends _.Hk {
    constructor(a, b, c, d) {
      super();
      this.Eg = _.eu(d.title);
      if ((this.Jg = d.XD || !1))
        this.Eg.setAttribute("role", "menuitemradio"),
          this.Eg.setAttribute("aria-checked", "false");
      _.Ym(this.Eg);
      a.appendChild(this.Eg);
      _.cD(this.Eg);
      this.Fg = this.Eg.style;
      this.Ig = d.Ai || !1;
      this.Fg.overflow = "hidden";
      d.nA ? kL(this.Eg) : (this.Fg.textAlign = "center");
      d.height &&
        ((this.Fg.height = _.ds(d.height)),
        (this.Fg.display = "table-cell"),
        (this.Fg.verticalAlign = "middle"));
      this.Fg.position = "relative";
      oL(this.Eg, d);
      d.Wx && OJa(this.Eg);
      d.jB && PJa(this.Eg);
      this.Eg.style.backgroundClip = "padding-box";
      this.Kg = d.yC || !1;
      this.Lg = d.Wx || !1;
      this.Eg.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
      d.gJ
        ? ((a = document.createElement("span")),
          (a.style.position = "relative"),
          _.Hs(a, new _.vl(3, 0), !_.Ly.Fj(), !0),
          a.appendChild(b),
          this.Eg.appendChild(a),
          (b = _.KG(_.Yn("arrow-down"), this.Eg)),
          _.Hs(b, new _.vl(8, 0), !_.Ly.Fj()),
          (b.style.top = "50%"),
          (b.style.marginTop = _.ds(-2)),
          this.set("active", !1),
          this.Eg.setAttribute("aria-haspopup", "true"),
          this.Eg.setAttribute("aria-expanded", "false"))
        : (this.Eg.appendChild(b),
          (b = new QL(this.Eg, c)),
          b.bindTo("value", this),
          this.bindTo("active", b),
          b.bindTo("enabled", this));
      d.LI && this.Eg.setAttribute("aria-haspopup", "true");
      d.yC && (this.Fg.fontWeight = "500");
      this.Hg = _.gE(this.Fg.paddingLeft) || 0;
      d.nA ||
        ((this.Fg.fontWeight = "500"),
        (d = this.Eg.offsetWidth - this.Hg - (_.gE(this.Fg.paddingRight) || 0)),
        (this.Fg.fontWeight = ""),
        _.xj(d) && d >= 0 && (this.Fg.minWidth = _.ds(d)));
      new _.Vm(this.Eg, "click", (e) => {
        this.get("enabled") !== !1 && _.Ek(this, "click", e);
      });
      new _.Vm(this.Eg, "keydown", (e) => {
        this.get("enabled") !== !1 && _.Ek(this, "keydown", e);
      });
      new _.Vm(this.Eg, "blur", (e) => {
        this.get("enabled") !== !1 && _.Ek(this, "blur", e);
      });
      new _.Vm(this.Eg, "mouseover", () => {
        PL(this, !0);
      });
      new _.Vm(this.Eg, "mouseout", () => {
        PL(this, !1);
      });
      _.sk(this, "enabled_changed", () => {
        PL(this, !1);
      });
      _.sk(this, "active_changed", () => {
        PL(this, !1);
      });
    }
    Ei() {
      return this.Eg;
    }
  };
  var bNa = (0,
  _.Tf)`.ssQIHO-checkbox-menu-item\u003espan\u003espan{background-color:#000;display:inline-block}@media (forced-colors:active),(prefers-contrast:more){.ssQIHO-checkbox-menu-item\u003espan\u003espan{background-color:ButtonText}}\n`;
  var cNa = class extends _.Hk {
    constructor(a, b, c, d, e) {
      super();
      this.Eg = document.createElement("li");
      a.appendChild(this.Eg);
      this.Eg.tabIndex = -1;
      this.Eg.setAttribute("role", "menuitemcheckbox");
      this.Eg.setAttribute("aria-label", b);
      this.Ai = e.Ai || !1;
      _.Ym(this.Eg);
      this.Fg = document.createElement("span");
      this.Fg.style["mask-image"] = `url("${_.fy["checkbox_checked.svg"]}")`;
      this.Fg.style[
        "-webkit-mask-image"
      ] = `url("${_.fy["checkbox_checked.svg"]}")`;
      this.Ai && (this.Fg.style.filter = "invert(100%)");
      this.Hg = document.createElement("span");
      this.Hg.style["mask-image"] = `url("${_.fy["checkbox_empty.svg"]}")`;
      this.Hg.style[
        "-webkit-mask-image"
      ] = `url("${_.fy["checkbox_empty.svg"]}")`;
      this.Ai && (this.Hg.style.filter = "invert(100%)");
      a = document.createElement("span");
      this.Eg.appendChild(a);
      a.appendChild(this.Fg);
      a.appendChild(this.Hg);
      this.label = document.createElement("label");
      this.Eg.appendChild(this.label);
      this.label.textContent = b;
      oL(this.Eg, e);
      b = _.Ly.Fj();
      _.cD(this.Eg);
      kL(this.Eg);
      this.Hg.style.height = this.Fg.style.height = "1em";
      this.Hg.style.width = this.Fg.style.width = "1em";
      this.Hg.style.transform = this.Fg.style.transform = "translateY(0.15em)";
      this.label.style.cursor = "inherit";
      this.Ai
        ? ((this.Eg.style.backgroundColor = "#444"),
          (this.Eg.style.color = "#fff"))
        : ((this.Eg.style.backgroundColor = "#fff"),
          (this.Eg.style.color = "#000"));
      this.Eg.style.whiteSpace = "nowrap";
      this.Eg.style[b ? "paddingLeft" : "paddingRight"] = _.ds(8);
      yKa(this, c, d);
      _.yq(bNa, this.Eg);
      _.Bl(this.Eg, "checkbox-menu-item");
    }
    Ei() {
      return this.Eg;
    }
  };
  var dNa = class extends _.Hk {
    constructor(a, b, c, d) {
      super();
      const e = (this.Eg = _.Is("li", a));
      oL(e, d);
      _.Es(b, e);
      e.style.backgroundColor = d?.Ai ? "#444" : "#fff";
      e.tabIndex = -1;
      e.setAttribute("role", "menuitemradio");
      e.setAttribute("aria-checked", "false");
      _.Ym(e);
      _.Ak(this, "active_changed", this, () => {
        const f = this.get("active") || !1;
        e.style.fontWeight = f ? "500" : "";
        e.setAttribute("aria-checked", f);
      });
      _.Ak(this, "enabled_changed", this, () => {
        var f = this.get("enabled") !== !1;
        e.style.color = d?.Ai ? (f ? "#fff" : "#aaa") : f ? "#000" : "#565656";
        (f = f ? d?.title : d?.JH) && e.setAttribute("title", f);
      });
      a = new QL(e, c);
      a.bindTo("value", this);
      a.bindTo("display", this);
      a.bindTo("enabled", this);
      this.bindTo("active", a);
      _.hs(e, "mouseover", this, () => {
        this.get("enabled") !== !1 &&
          (d?.Ai
            ? ((e.style.backgroundColor = "#666"), (e.style.color = "#fff"))
            : ((e.style.backgroundColor = "#ebebeb"),
              (e.style.color = "#000")));
      });
      _.yk(e, "mouseout", () => {
        d?.Ai
          ? ((e.style.backgroundColor = "#444"), (e.style.color = "#aaa"))
          : ((e.style.backgroundColor = "#fff"), (e.style.color = "#565656"));
      });
    }
    Ei() {
      return this.Eg;
    }
  };
  var eNa = class extends _.Hk {
    constructor(a) {
      super();
      const b = _.Is("div", a);
      b.style.margin = "1px 0";
      b.style.borderTop = "1px solid #ebebeb";
      a = this.get("display");
      b &&
        (b.setAttribute("aria-hidden", "true"),
        (b.style.visibility = b.style.visibility || "inherit"),
        (b.style.display = a ? "" : "none"));
      _.Ak(this, "display_changed", this, function () {
        b.style.display = this.get("display") !== !1 ? "" : "none";
      });
    }
  };
  var FKa = class extends _.Hk {
    constructor(a, b, c, d, e, f = {}) {
      super();
      this.Lg = a;
      this.Yg = b;
      this.Ig = e;
      this.Hg = [];
      this.Fg = null;
      this.shadowRoot = (this.Kg = b.getRootNode() instanceof ShadowRoot)
        ? b.getRootNode()
        : null;
      a = this.Eg = _.Is("ul", b);
      a.style.backgroundColor = f.Ai ? "#444" : "#fff";
      a.style.listStyle = "none";
      a.style.margin = a.style.padding = "0";
      _.Js(a, -1);
      a.style.padding = _.ds(2);
      NJa(a, _.ds(_.CG(d)));
      a.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
      f.position
        ? _.Hs(a, f.position, f.LK)
        : ((a.style.position = "absolute"),
          (a.style.top = "100%"),
          (a.style.left = "0"),
          (a.style.right = "0"));
      kL(a);
      _.qE(a);
      b = this.Ig.id || (this.Ig.id = _.co());
      a.setAttribute("role", "menu");
      for (a.setAttribute("aria-labelledby", b); _.rj(c); ) {
        b = c.shift();
        for (const g of b) {
          let h;
          e = {
            title: g.alt,
            JH: g.Ig || void 0,
            fontSize: rL(d),
            padding: [(1 + d) >> 3],
            Ai: f.Ai || !1,
          };
          g.Hg != null
            ? (h = new cNa(a, g.label, g.Eg, g.Hg, e))
            : (h = new dNa(a, g.label, g.Eg, e));
          h.bindTo("value", this.Lg, g.Sn);
          h.bindTo("display", g);
          h.bindTo("enabled", g);
          this.Hg.push(h);
        }
        e = c.flat();
        if (e.length) {
          const g = new eNa(a);
          zKa(g, b, e);
        }
      }
    }
    Jg() {
      const a = this.Eg;
      a.timeout && (window.clearTimeout(a.timeout), (a.timeout = null));
    }
    active_changed() {
      this.Jg();
      if (this.get("active")) CKa(this);
      else {
        const a = this.Eg;
        a.ph && (a.ph.forEach(_.uk), (a.ph = null));
        a.contains(RL(this)) && this.Ig.focus();
        this.Fg = null;
        _.qE(a);
      }
    }
  };
  var EKa = (0,
  _.Tf)`.gm-style .gm-style-mtc label,.gm-style .gm-style-mtc div{font-weight:400}.gm-style .gm-style-mtc ul,.gm-style .gm-style-mtc li{-webkit-box-sizing:border-box;box-sizing:border-box}.gm-style-mtc-bbw{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap}.gm-style-mtc-bbw .gm-style-mtc:first-of-type\u003ebutton{border-start-start-radius:2px;border-end-start-radius:2px}.gm-style-mtc-bbw .gm-style-mtc:last-of-type\u003ebutton{border-start-end-radius:2px;border-end-end-radius:2px}sentinel{}\n`;
  var wMa = class extends _.Hk {
    constructor(a, b, c, d) {
      super();
      this.Yg = a;
      this.Eg = [];
      this.Yg.setAttribute("role", "menubar");
      this.Yg.classList.add("gm-style-mtc-bbw");
      this.Fg = c;
      this.Hg = d;
      _.sk(this, "fontloaded_changed", () => {
        if (this.get("fontLoaded")) {
          var e = this.Eg.length,
            f = 0;
          for (let g = 0; g < e; ++g) {
            const h = _.en(this.Eg[g].parentNode),
              k = g === e - 1;
            this.Eg[g].mq &&
              _.Hs(this.Eg[g].mq.Eg, new _.vl(k ? 0 : f, h.height), k);
            f += h.width;
          }
          this.Eg.length = 0;
        }
      });
      _.sk(this, "mapsize_changed", () => {
        DKa(this);
      });
      _.sk(this, "display_changed", () => {
        DKa(this);
      });
      c = b.length;
      d = 0;
      for (let e = 0; e < c; ++e) d = HKa(this, b[e], d, e === c - 1);
      _.zE();
      a.style.cursor = "pointer";
    }
  };
  var vMa = class extends _.Hk {
    constructor(a, b, c, d) {
      super();
      this.Yg = a;
      _.zE();
      a.style.cursor = "pointer";
      kL(a);
      a.style.width = _.ds(120);
      _.yq(EKa, document.head);
      _.Cs(a, "gm-style-mtc");
      const e = _.Es("", a, !0);
      d = _.OL(a, e, null, {
        title: "Thay \u0111\u1ed5i ki\u1ec3u b\u1ea3n \u0111\u1ed3",
        gJ: !0,
        nA: !0,
        yC: !0,
        padding: [8, 17],
        fontSize: 18,
        Wx: !0,
        jB: !0,
        Ai: d === 2,
      });
      const f = {},
        g = [b];
      for (const k of b)
        k.Sn === "mapTypeId" && (f[k.Eg] = k.label), k.Fg && g.push(...k.Fg);
      this.addListener("maptypeid_changed", () => {
        var k = f[this.get("mapTypeId")] || "";
        e.textContent = k;
      });
      const h = d.Ei();
      this.mq = new FKa(this, a, g, c, h);
      d.addListener("click", (k) => {
        this.mq.set("active", !this.mq.get("active"));
        const m = _.uE(k) ? 164753 : 164752;
        _.pl(window, _.uE(k) ? "Mtcmi" : "Mtcki");
        _.M(window, m);
      });
      d.addListener("keydown", (k) => {
        (k.key !== "ArrowDown" && k.key !== "ArrowUp") ||
          this.mq.set("active", !0);
      });
      this.mq.addListener("active_changed", () => {
        h.setAttribute(
          "aria-expanded",
          this.mq.get("active") ? "true" : "false"
        );
      });
    }
    mapSize_changed() {
      IKa(this);
    }
    display_changed() {
      IKa(this);
    }
  };
  var xMa = class extends _.Hk {
    constructor(a) {
      super();
      this.Eg = !1;
      this.map = a;
    }
    changed(a) {
      if (!this.Eg)
        if (a === "mapTypeId") {
          a = this.get("mapTypeId");
          var b = this.map[a];
          b && b.mapTypeId && (a = b.mapTypeId);
          SL(this, "internalMapTypeId", a);
          b && b.Cv && SL(this, b.Cv, b.value);
        } else {
          a = this.get("internalMapTypeId");
          if (this.map)
            for (const [c, d] of Object.entries(this.map)) {
              b = c;
              const e = d;
              e &&
                e.mapTypeId === a &&
                e.Cv &&
                this.get(e.Cv) == e.value &&
                (a = b);
            }
          SL(this, "mapTypeId", a);
        }
    }
  };
  var SLa = class extends _.Hk {
    constructor(a, b, c, d = !1) {
      super();
      this.Fg = a;
      this.Ig = "";
      this.Ng = _.HL(a, b.getDiv(), d);
      this.Kg = KKa();
      _.qE(a);
      this.Eg = LKa(this.Ng);
      this.Eg.style.color = d ? "#fff" : "#000000";
      _.yk(this.Eg, "click", (e) => {
        _.ps(b, "Rc");
        _.as(161529);
        const f = _.uE(e) ? 165226 : 165225;
        _.pl(window, _.uE(e) ? "Rmimi" : "Rmiki");
        _.M(window, f);
      });
      this.Hg = b;
      this.Jg = c;
    }
    sessionState_changed() {
      var a = this.get("sessionState");
      if (a) {
        var b = new _.jJ();
        _.Tr(b, a);
        a = _.Hi(b.Gg, 10, _.yGa);
        _.Fi(a.Gg, 1, 1);
        _.Ci(b.Gg, 12, !0);
        b = _.aHa(b, this.Jg);
        b += "&rapsrc=apiv3";
        _.Ar(this.Eg, _.MD(b));
        this.Ig = b;
        this.get("available") &&
          this.set("rmiLinkData", {
            label: "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3",
            tooltip:
              "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google",
            url: this.Ig,
          });
      }
    }
    available_changed() {
      TL(this);
    }
    enabled_changed() {
      TL(this);
    }
    mapTypeId_changed() {
      TL(this);
    }
    Sq() {
      MKa(this) &&
        (_.zE(),
        _.pl(this.Hg, "Rs"),
        _.M(this.Hg, 148263),
        (this.Fg.style.display = ""),
        (this.Eg.textContent = ""),
        this.Eg.appendChild(this.Kg));
    }
    Rq() {
      MKa(this) &&
        (_.zE(),
        _.pl(this.Hg, "Rs"),
        _.M(this.Hg, 148263),
        (this.Fg.style.display = ""),
        (this.Eg.textContent =
          "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3"));
    }
    Kj() {
      this.Fg.style.display = "none";
    }
    Fl() {
      return this.Fg;
    }
  };
  var fNa = class extends _.Hk {
    constructor(a, b, c) {
      super();
      this.Yg = a;
      this.Eg = b;
      this.Hg = !0;
      a = _.an[43] ? "rgb(34, 34, 34)" : "rgb(255, 255, 255)";
      _.yq(gM, c);
      this.Fg = _.Is("div", this.Yg);
      this.Fg.style.backgroundColor = a;
      this.Fg.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
      this.Fg.style.borderRadius = _.ds(_.CG(this.Eg));
      this.Ig = _.eu(
        "Xoay b\u1ea3n \u0111\u1ed3 theo chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3"
      );
      this.Ig.style.left = "0";
      this.Ig.style.top = "0";
      this.Ig.style.overflow = "hidden";
      this.Ig.setAttribute("class", "gm-control-active");
      _.dn(this.Ig, new _.xl(this.Eg, this.Eg));
      _.Ls(this.Ig);
      OKa(this.Ig, this.Eg, !1);
      this.Fg.appendChild(this.Ig);
      this.Lg = PKa(this.Eg);
      this.Fg.appendChild(this.Lg);
      this.Jg = _.eu(
        "Xoay b\u1ea3n \u0111\u1ed3 ng\u01b0\u1ee3c chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3"
      );
      this.Jg.style.left = "0";
      this.Jg.style.top = "0";
      this.Jg.style.overflow = "hidden";
      this.Jg.setAttribute("class", "gm-control-active");
      _.dn(this.Jg, new _.xl(this.Eg, this.Eg));
      _.Ls(this.Jg);
      OKa(this.Jg, this.Eg, !0);
      this.Fg.appendChild(this.Jg);
      this.Mg = PKa(this.Eg);
      this.Fg.appendChild(this.Mg);
      this.Kg = _.eu("Nghi\u00eang b\u1ea3n \u0111\u1ed3");
      this.Kg.style.left = this.Kg.style.top = "0";
      this.Kg.style.overflow = "hidden";
      this.Kg.setAttribute("class", "gm-tilt gm-control-active");
      NKa(this.Kg, !1, this.Eg);
      _.dn(this.Kg, new _.xl(this.Eg, this.Eg));
      _.Ls(this.Kg);
      this.Fg.appendChild(this.Kg);
      this.Ig.addEventListener("click", (d) => {
        const e = +this.get("heading") || 0;
        this.set("heading", (e + 270) % 360);
        QKa(d);
      });
      this.Jg.addEventListener("click", (d) => {
        const e = +this.get("heading") || 0;
        this.set("heading", (e + 90) % 360);
        QKa(d);
      });
      this.Kg.addEventListener("click", (d) => {
        this.Hg = !this.Hg;
        this.set("tilt", this.Hg ? 45 : 0);
        const e = _.uE(d) ? 164824 : 164823;
        _.pl(window, _.uE(d) ? "Tcmi" : "Tcki");
        _.M(window, e);
      });
      _.sk(this, "aerialavailableatzoom_changed", () => {
        this.refresh();
      });
      _.sk(this, "tilt_changed", () => {
        this.Hg = this.get("tilt") !== 0;
        this.refresh();
      });
      _.sk(this, "mapsize_changed", () => {
        this.refresh();
      });
      _.sk(this, "rotatecontrol_changed", () => {
        this.refresh();
      });
    }
    refresh() {
      var a = this.get("mapSize"),
        b = !!this.get("aerialAvailableAtZoom");
      a =
        !!this.get("rotateControl") || (a && a.width >= 200 && a.height >= 200);
      b = b && a;
      a = this.Yg;
      NKa(this.Kg, this.Hg, this.Eg);
      this.Ig.style.display = this.Hg ? "block" : "none";
      this.Lg.style.display = this.Hg ? "block" : "none";
      this.Jg.style.display = this.Hg ? "block" : "none";
      this.Mg.style.display = this.Hg ? "block" : "none";
      const c = this.Eg;
      var d = Math.floor(3 * this.Eg) + 2;
      d = this.Hg ? d : this.Eg;
      this.Fg.style.width = _.ds(c);
      this.Fg.style.height = _.ds(d);
      a.dataset.controlWidth = String(c);
      a.dataset.controlHeight = String(d);
      a.style.display = b ? "" : "none";
      _.Ek(a, "resize");
    }
  };
  var DMa = class extends _.Hk {
    constructor(a, b, c) {
      super();
      a = new fNa(a, b, c);
      a.bindTo("mapSize", this);
      a.bindTo("rotateControl", this);
      a.bindTo("aerialAvailableAtZoom", this);
      a.bindTo("heading", this);
      a.bindTo("tilt", this);
    }
  };
  var QLa = class {
    constructor(a, b, c, d = !1) {
      this.Yg = a;
      this.Fg = !1;
      this.Kg = c;
      this.Hg = d;
      c = new _.dj(b.nodeType == 9 ? b : b.ownerDocument || b.document);
      this.Ig = c.createElement("span");
      c.appendChild(b, this.Ig);
      this.Ig.style.color = d ? "#fff" : "#000000";
      this.Eg = c.createElement("div");
      c.appendChild(b, this.Eg);
      RKa(this, c);
      this.Jg = !0;
      b = _.co();
      d = document.createElement("span");
      d.id = b;
      d.textContent =
        "Nh\u1ea5p \u0111\u1ec3 chuy\u1ec3n \u0111\u1ed5i gi\u1eefa c\u00e1c \u0111\u01a1n v\u1ecb h\u1ec7 m\u00e9t v\u00e0 h\u1ec7 \u0111o l\u01b0\u1eddng Anh";
      d.style.display = "none";
      a.appendChild(d);
      a.setAttribute("aria-describedby", b);
      _.eg(a, "click", (e) => {
        this.Jg = !this.Jg;
        UL(this);
        _.uE(e)
          ? (_.pl(window, "Scmi"), _.M(window, 165091))
          : (_.pl(window, "Scki"), _.M(window, 167511));
      });
      _.Zq(this.Kg, () => UL(this));
    }
    enable() {
      this.Fg = !0;
      UL(this);
    }
    disable() {
      this.Fg = !1;
      UL(this);
    }
    show() {
      this.Fg && (this.Yg.style.display = "");
    }
    Kj() {
      this.Fg || (this.Yg.style.display = "none");
    }
    Sq() {
      this.show();
    }
    Rq() {
      this.show();
    }
    Fl() {
      return this.Yg;
    }
  };
  _.Ia(WL, _.BG);
  WL.prototype.fill = function (a) {
    _.zG(this, 0, a);
  };
  var VL = "t-avKK8hDgg9Q";
  var ZLa = class {
    constructor(a) {
      this.Eg = 0;
      this.Yg = document.createElement("div");
      this.Yg.style.display = "inline-flex";
      this.Fg = new _.Nm(() => {
        this.update(this.Eg);
      }, 0);
      this.Vs = a.Vs;
      this.Mw = $Ka(this, a.Mw);
      for (const b of this.Vs)
        b.Kj(),
          (a = b.Fl()),
          this.Yg.appendChild(a),
          _.sk(a, "resize", () => {
            _.Om(this.Fg);
          });
    }
    update(a) {
      this.Eg = a;
      for (var b of this.Vs) b.Kj(), b.Sq();
      if (a < this.Yg.offsetWidth)
        for (var c of this.Mw)
          if (((b = this.Yg.offsetWidth), a < b)) c.Kj();
          else break;
      else
        for (c = this.Mw.length - 1; c >= 0; c--) {
          const d = this.Mw[c];
          d.Rq();
          b = this.Yg.offsetWidth;
          a < b && d.Sq();
        }
      _.Ek(this.Yg, "resize");
    }
  };
  var XL = {},
    gNa = (XL[1] = {});
  gNa.backgroundColor = "#fff";
  gNa.hD = "#e6e6e6";
  var hNa = (XL[2] = {});
  hNa.backgroundColor = "#444";
  hNa.hD = "#1a1a1a";
  var iNa = class extends _.Hk {
    constructor(a, b, c, d = 1) {
      super();
      this.Yg = a;
      this.Kg = !1;
      this.set("colorTheme", d ? d : 1);
      this.get("colorTheme");
      this.Fg = b;
      this.Eg = _.Is("div", a);
      _.Ls(this.Eg);
      _.Ks(this.Eg);
      this.Eg.style.boxShadow = "0 1px 4px -1px rgba(0,0,0,0.3)";
      this.Eg.style.borderRadius = _.ds(_.CG(b));
      this.Eg.style.cursor = "pointer";
      _.yq(gM, c);
      _.yk(this.Eg, "mouseover", () => {
        this.set("mouseover", !0);
      });
      _.yk(this.Eg, "mouseout", () => {
        this.set("mouseover", !1);
      });
      this.Ig = aLa(this, this.Eg, 0, d);
      this.Hg = _.Is("div", this.Eg);
      this.Hg.style.position = "relative";
      this.Hg.style.overflow = "hidden";
      this.Hg.style.width = _.ds((3 * b) / 4);
      this.Hg.style.height = _.ds(1);
      this.Hg.style.margin = "0 5px";
      this.Jg = aLa(this, this.Eg, 1, d);
      _.sk(this, "display_changed", () => bLa(this));
      _.sk(this, "mapsize_changed", () => bLa(this));
      _.sk(this, "maptypeid_changed", () => {
        var e = this.get("mapTypeId");
        e =
          ((e === "satellite" || e === "hybrid") && _.an[43]) ||
          e == "streetview"
            ? 2
            : this.get("colorTheme");
        cLa(this, e);
      });
      _.sk(this, "colortheme_changed", () => {
        cLa(this, this.get("colorTheme"));
      });
    }
    changed(a) {
      if (a === "zoom" || a === "zoomRange") {
        a = this.get("zoom");
        const b = this.get("zoomRange");
        WJa(a, b, this.Ig, this.Jg);
      }
    }
  };
  var AMa = class extends _.Hk {
    constructor(a, b, c) {
      super();
      const d = (this.Eg = _.Is("div"));
      _.nL(d);
      a = new iNa(d, a, b, c);
      a.bindTo("mapSize", this);
      a.bindTo("display", this, "display");
      a.bindTo("mapTypeId", this);
      a.bindTo("zoom", this);
      a.bindTo("zoomRange", this);
      this.pw = a;
    }
    getDiv() {
      return this.Eg;
    }
  };
  var eLa = class extends _.Hk {
    constructor(a, b, c, d) {
      super();
      _.nL(a);
      _.Js(a, 1000001);
      this.Eg = a;
      a = _.Is("div", a);
      b = _.HL(a, b, d);
      this.Kg = a;
      a = _.eu("D\u1eef li\u1ec7u B\u1ea3n \u0111\u1ed3");
      b.appendChild(a);
      a.textContent = "D\u1eef li\u1ec7u B\u1ea3n \u0111\u1ed3";
      a.style.color = this.Hg ? "#fff" : "#000000";
      a.style.display = "inline-block";
      a.style.fontFamily = "inherit";
      a.style.lineHeight = "inherit";
      _.mE(a, "click", this);
      this.Fg = a;
      this.Hg = d;
      d = _.Is("span", b);
      d.style.display = "none";
      this.Ig = d;
      this.Jg = c;
      YL(this);
    }
    fontLoaded_changed() {
      YL(this);
    }
    attributionText_changed() {
      YL(this);
    }
    hidden_changed() {
      YL(this);
    }
    mapTypeId_changed() {
      this.get("mapTypeId") === "streetview" &&
        (IL(this.Kg), (this.Fg.style.color = "#fff"));
    }
    Sq() {
      this.get("hidden") ||
        ((this.Eg.style.display = ""),
        (this.Fg.style.display = ""),
        (this.Fg.style.color = this.Hg ? "#fff" : "#000000"),
        (this.Ig.style.display = "none"),
        _.zE());
    }
    Rq() {
      this.get("hidden") ||
        ((this.Eg.style.display = ""),
        (this.Fg.style.display = "none"),
        (this.Ig.style.display = ""),
        (this.Fg.style.color = this.Hg ? "#fff" : "#000000"),
        _.zE());
    }
    Kj() {
      this.get("hidden") && (this.Eg.style.display = "none");
    }
    Fl() {
      return this.Eg;
    }
  };
  var jNa = class extends _.Hk {
    constructor(a) {
      super();
      this.Hg = a.ownerElement;
      this.Fg = document.createElement("div");
      this.Fg.style.color = "#222";
      this.Fg.style.maxWidth = "280px";
      this.Eg = new _.FK({
        content: this.Fg,
        title: "D\u1eef li\u1ec7u B\u1ea3n \u0111\u1ed3",
      });
      _.Bl(this.Eg, "copyright-dialog-view");
    }
    Ei() {
      return this.Eg;
    }
    visible_changed() {
      this.get("visible")
        ? (_.zE(), this.Hg.appendChild(this.Eg), this.Eg.Eg.showModal())
        : this.Eg.close();
    }
    attributionText_changed() {
      const a = this.get("attributionText") || "";
      (this.Fg.textContent = a) || this.Eg.close();
    }
  };
  var gLa = class extends _.Hk {
    constructor(a) {
      super();
      _.lL(a, "gmnoprint");
      _.Cs(a, "gmnoscreen");
      this.Eg = a;
      a = this.Fg = _.Is("div", a);
      a.style.fontFamily = "Roboto,Arial,sans-serif";
      a.style.fontSize = _.ds(11);
      a.style.color = "#000000";
      a.style.direction = "ltr";
      a.style.textAlign = "right";
      a.style.backgroundColor = "#f5f5f5";
    }
    attributionText_changed() {
      const a = this.get("attributionText") || "";
      this.Fg.textContent = a;
    }
    hidden_changed() {
      const a = !this.get("hidden");
      _.pE(this.Eg, a);
      a && _.zE();
    }
    Sq() {}
    Rq() {}
    Kj() {}
    Fl() {
      return this.Eg;
    }
  };
  var iLa = class extends _.Hk {
    constructor(a, b, c) {
      super();
      _.nL(a);
      _.Js(a, 1000001);
      this.Eg = a;
      this.Fg = _.HL(a, b, c);
      this.Hg = a = _.Is("a", this.Fg);
      a.style.textDecoration = "none";
      a.style.cursor = "pointer";
      a.textContent = "\u0110i\u1ec1u kho\u1ea3n";
      _.Ar(a, _.Oy);
      a.target = "_blank";
      a.rel = "noopener";
      a.style.color = c ? "#fff" : "#000000";
      a.addEventListener("click", (d) => {
        const e = _.uE(d) ? 165234 : 165233;
        _.pl(window, _.uE(d) ? "Tscmi" : "Tscki");
        _.M(window, e);
      });
    }
    hidden_changed() {
      _.Ek(this.Eg, "resize");
    }
    mapTypeId_changed() {
      this.get("mapTypeId") === "streetview" &&
        (IL(this.Eg), (this.Hg.style.color = "#fff"));
    }
    fontLoaded_changed() {
      _.Ek(this.Eg, "resize");
    }
    Sq() {
      this.Rq();
    }
    Rq() {
      this.get("hidden") || ((this.Eg.style.display = ""), _.zE());
    }
    Kj() {
      this.get("hidden") && (this.Eg.style.display = "none");
    }
    Fl() {
      return this.Eg;
    }
  };
  var LLa = class extends _.Hk {
    constructor(a, b, c, d, e) {
      super();
      var f = c instanceof _.Gl;
      f = new UMa(_.Is("div"), a, f ? !0 : e);
      f.bindTo("keyboardShortcutsShown", this);
      f.bindTo("fontLoaded", this);
      d = fLa(a, d, e);
      d.bindTo("attributionText", this);
      d.bindTo("fontLoaded", this);
      d.bindTo("isCustomPanorama", this);
      c.__gm.get("innerContainer");
      const g = new jNa({ ownerElement: b });
      g.bindTo("attributionText", this);
      _.sk(d, "click", (h) => {
        g.set("visible", !0);
        const k = _.uE(h) ? 165049 : 165048;
        _.pl(window, _.uE(h) ? "Ccmi" : "Ccki");
        _.M(window, k);
      });
      b = hLa();
      b.bindTo("attributionText", this);
      a = jLa(a, e);
      a.bindTo("fontLoaded", this);
      a.bindTo("mapTypeId", this);
      d.bindTo("mapTypeId", this);
      c && _.an[28]
        ? (d.bindTo("hidden", c, "hideLegalNotices"),
          b.bindTo("hidden", c, "hideLegalNotices"),
          a.bindTo("hidden", c, "hideLegalNotices"))
        : (d.bindTo("isCustomPanorama", this),
          b.bindTo("hidden", this, "isCustomPanorama"));
      this.Fg = d;
      this.Hg = b;
      this.Ig = a;
      this.Eg = f;
    }
  };
  var kNa = class extends _.Hk {
    constructor() {
      var a = _.L(_.Mi.Eg().Gg, 15);
      super();
      this.Eg = a.replace("www.google", "maps.google");
    }
    changed(a) {
      if (a !== "url")
        if (this.get("pano")) {
          a = this.get("pov");
          var b = this.get("position");
          a &&
            b &&
            ((a = _.cHa(a, b, this.get("pano"), this.Eg)), this.set("url", a));
        } else {
          a = {};
          if ((b = this.get("center")))
            (b = new _.ek(b.lat(), b.lng())), (a.ll = b.toUrlValue());
          b = this.get("zoom");
          _.xj(b) && (a.z = b);
          b = this.get("mapTypeId");
          (b = b === "terrain" ? "p" : b === "hybrid" ? "h" : _.tx[b]) &&
            (a.t = b);
          if ((b = this.get("pano"))) {
            a.z = 17;
            a.layer = "c";
            const d = this.get("position");
            d && (a.cbll = d.toUrlValue());
            a.panoid = b;
            (b = this.get("pov")) &&
              (a.cbp = `12,${b.heading},,${Math.max(b.zoom - 3)},${-b.pitch}`);
          }
          a.hl = _.Mi.Eg().Eg();
          a.gl = _.Mi.Eg().Fg();
          a.mapclient = _.an[35] ? "embed" : "apiv3";
          const c = [];
          _.sj(a, (d, e) => {
            c.push(`${d}=${e}`);
          });
          this.set("url", this.Eg + "?" + c.join("&"));
        }
    }
  };
  var lNa = class extends _.Hk {
    constructor() {
      var a = _.Mi.Eg();
      super();
      this.locale = a;
    }
    changed(a) {
      if (a !== "sessionState") {
        a = new _.jJ();
        var b = this.get("zoom"),
          c = this.get("center"),
          d = this.get("pano");
        if ((b != null && c != null) || d != null) {
          var e = this.locale,
            f = _.Hi(a.Gg, 2, _.KI),
            g = e.Eg();
          _.Xg(f.Gg, 1, g);
          f = _.Hi(a.Gg, 2, _.KI);
          e = e.Fg();
          _.Xg(f.Gg, 2, e);
          e = _.HI(a);
          f = this.get("mapTypeId");
          f === "hybrid" || f === "satellite"
            ? _.Fi(e.Gg, 1, 3)
            : (_.Fi(e.Gg, 1, 0),
              f === "terrain" &&
                ((f = _.Hi(a.Gg, 5, _.oGa)), _.Ei(f.Gg, 1, 4)));
          f = _.Hi(e.Gg, 2, _.MI);
          _.Fi(f.Gg, 1, 2);
          c &&
            ((g = c.lng()), _.Qs(f.Gg, 2, g), (c = c.lat()), _.Qs(f.Gg, 3, c));
          typeof b === "number" && _.Xr(f.Gg, 6, b);
          f.setHeading(this.get("heading") || 0);
          d && ((b = _.Hi(e.Gg, 3, _.PI)), _.Xg(b.Gg, 1, d));
          this.set("sessionState", a);
        } else this.set("sessionState", null);
      }
    }
  };
  var EMa = class extends _.Hk {
    constructor(a, b) {
      super();
      this.Eg = b;
      this.Fg = [];
      _.Ls(a);
      _.Ks(a);
      a.style.fontFamily = "Roboto,Arial,sans-serif";
      a.style.fontSize = _.ds(Math.round((11 * b) / 40));
      a.style.textAlign = "center";
      a.style.boxShadow = "rgba(0, 0, 0, 0.3) 0px 1px 4px -1px";
      a.dataset.controlWidth = String(b);
      a.style.cursor = "pointer";
      this.Yg = a;
    }
    floors_changed() {
      const a = this.get("floorId"),
        b = this.get("floors") || [],
        c = this.Yg;
      if (b.length > 1) {
        _.rE(c);
        _.Kb(this.Fg, (d) => {
          _.Rs(d);
        });
        this.Fg = [];
        for (let d = b.length, e = d - 1; e >= 0; --e) {
          const f = _.eu(b[e].description || b[e].qC || "T\u1ea7ng");
          b[e].yz == a
            ? ((f.style.color = "#aaa"),
              (f.style.fontWeight = "bold"),
              (f.style.backgroundColor = "#333"))
            : (kLa(this, f, b[e].pK),
              (f.style.color = "#999"),
              (f.style.fontWeight = "400"),
              (f.style.backgroundColor = "#222"));
          f.style.height = f.style.width = _.ds(this.Eg);
          e === d - 1
            ? MJa(f, _.ds(_.CG(this.Eg)))
            : e === 0 && NJa(f, _.ds(_.CG(this.Eg)));
          _.Es(b[e].qC, f);
          c.appendChild(f);
          this.Fg.push(f);
        }
        setTimeout(() => {
          _.Ek(c, "resize");
        });
      } else c.style.display = "none";
    }
  };
  var CLa = class extends _.Hk {
    constructor(a, b, c, d, e) {
      super();
      this.Yg = a;
      this.Eg = b;
      this.Hg = c;
      this.Jg = d;
      this.visible = !0;
      this.set("isOnLeft", !1);
      a.classList.add("gm-svpc");
      a.setAttribute("dir", "ltr");
      a.style.background = e ? "#444" : "#fff";
      b = this.Eg < 32 ? this.Eg - 2 : this.Eg < 40 ? 30 : 10 + this.Eg / 2;
      this.Fg = { Yz: lLa(b), active: mLa(b), Xz: nLa(b) };
      pLa(this);
      this.set("position", _.IK.nK.offset);
      _.hs(a, "mouseover", this, this.Ig);
      _.hs(a, "mouseout", this, this.Kg);
      a.addEventListener("keyup", (f) => {
        !f.altKey && _.Uw(f) && this.Jg(f);
      });
      a.addEventListener("pointerdown", (f) => {
        this.Hg(f);
      });
      a.addEventListener(
        "touchstart",
        (f) => {
          this.Hg(f);
        },
        { passive: !1 }
      );
      _.sk(this, "mode_changed", () => {
        const f = this.get("mode");
        oLa(this, f);
      });
      _.sk(this, "display_changed", () => {
        qLa(this);
      });
      _.sk(this, "mapsize_changed", () => {
        qLa(this);
      });
      this.set("mode", 1);
    }
    Ig() {
      this.get("mode") === 1 && this.set("mode", 2);
    }
    Kg() {
      this.get("mode") === 2 && this.set("mode", 1);
    }
    isOnLeft_changed() {
      this.Yg.style.setProperty(
        "--pegman-scaleX",
        String(this.get("isOnLeft") ? -1 : 1)
      );
    }
  };
  var mNa = [
      _.fy["lilypad_0.svg"],
      _.fy["lilypad_1.svg"],
      _.fy["lilypad_2.svg"],
      _.fy["lilypad_3.svg"],
      _.fy["lilypad_4.svg"],
      _.fy["lilypad_5.svg"],
      _.fy["lilypad_6.svg"],
      _.fy["lilypad_7.svg"],
      _.fy["lilypad_8.svg"],
      _.fy["lilypad_9.svg"],
      _.fy["lilypad_10.svg"],
      _.fy["lilypad_11.svg"],
      _.fy["lilypad_12.svg"],
      _.fy["lilypad_13.svg"],
      _.fy["lilypad_14.svg"],
      _.fy["lilypad_15.svg"],
    ],
    yLa = [
      _.fy["lilypad_pegman_0.svg"],
      _.fy["lilypad_pegman_1.svg"],
      _.fy["lilypad_pegman_2.svg"],
      _.fy["lilypad_pegman_3.svg"],
      _.fy["lilypad_pegman_4.svg"],
      _.fy["lilypad_pegman_5.svg"],
      _.fy["lilypad_pegman_6.svg"],
      _.fy["lilypad_pegman_7.svg"],
      _.fy["lilypad_pegman_8.svg"],
      _.fy["lilypad_pegman_9.svg"],
      _.fy["lilypad_pegman_10.svg"],
      _.fy["lilypad_pegman_11.svg"],
      _.fy["lilypad_pegman_12.svg"],
      _.fy["lilypad_pegman_13.svg"],
      _.fy["lilypad_pegman_14.svg"],
      _.fy["lilypad_pegman_15.svg"],
    ],
    nNa = class extends _.Hk {
      constructor(a) {
        super();
        this.map = a;
        this.Kg = this.Jg = 0;
        this.Lg = this.Og = !1;
        this.Tg = this.Rg = -1;
        this.Qg = this.Sg = null;
        var b = {
          clickable: !1,
          crossOnDrag: !1,
          draggable: !0,
          map: a,
          mapOnly: !0,
          internalMarker: !0,
          zIndex: 1e6,
        };
        this.Pg = _.IK.lq;
        this.Ug = _.IK.MK;
        this.Fg = _.jl("mode");
        this.Eg = _.kl("mode");
        this.Ig = rLa(this);
        this.Ng = sLa(this.Ig);
        this.Hg = tLa(this);
        this.Jx = a = new _.Hl(b);
        this.Mg = b = new _.Hl(b);
        this.Eg(1);
        this.set("heading", 0);
        a.bindTo("icon", this, "lilypadIcon");
        a.bindTo("dragging", this);
        b.set("cursor", _.dx);
        b.set("icon", sL(this.Ug, 0));
        b.bindTo("dragging", this);
        _.sk(this, "dragstart", this.fm);
        _.sk(this, "drag", this.fn);
        this.Wg = () => {
          this.Em();
        };
        this.Vg = () => {
          vLa(this);
        };
        wLa(this);
      }
      async ys(a) {
        this.Lg = !0;
        const b = _.xJ(a);
        if (b) {
          var c = await this.Hg;
          c.map = this.map;
          c.vB(b);
          await c.uD();
          c.ys(a);
        }
      }
      async zs(a) {
        this.Lg = !0;
        const b = await this.Hg;
        b.map = this.map;
        b.position = this.map.getCenter();
        await b.uD();
        b.zs(a);
      }
      async dragPosition_changed() {
        this.Mg.set("position", this.get("dragPosition"));
        (await this.Hg).position = this.get("dragPosition");
      }
      async mode_changed() {
        zLa(this);
        ALa(this);
        const a = this.get("mode"),
          b = await this.Hg;
        a === 0 || a === 1
          ? ((b.position = null), (b.map = null))
          : (b.map = this.map);
      }
      heading_changed() {
        this.Fg() === 7 && zLa(this);
      }
      position_changed() {
        var a = this.Fg();
        if (_.qJ(a))
          if (this.get("position")) {
            this.Jx.setVisible(!0);
            this.Mg.setVisible(!1);
            a = this.set;
            var b = xLa(this);
            this.Rg !== b &&
              ((this.Rg = b),
              (this.Qg = {
                url: mNa[b],
                scaledSize: new _.xl(49, 52),
                anchor: new _.vl(25, 35),
              }));
            a.call(this, "lilypadIcon", this.Qg);
          } else (a = this.Fg()), a === 5 ? this.Eg(6) : a === 3 && this.Eg(4);
        else
          (b = this.get("position")) && a === 1 && this.Eg(7),
            this.set("dragPosition", b);
        this.Jx.set("position", this.get("position"));
      }
      fm(a) {
        this.set("dragging", !0);
        this.Eg(5);
        this.Kg = a.pixel?.x ?? 0;
        ZL(this);
      }
      fn(a) {
        BLa(this, a);
        ALa(this);
        window.clearTimeout(this.Jg);
        this.Jg = window.setTimeout(() => {
          _.Ek(this, "hover");
          this.Jg = 0;
        }, 300);
        ZL(this);
      }
      async Em() {
        await ZL(this);
        _.Ek(this, "dragend");
        uLa(this);
      }
    };
  var FMa = class extends _.Hk {
    constructor(a, b, c, d, e, f, g, h, k, m) {
      var p = _.Mi;
      super();
      this.map = a;
      this.Og = d;
      this.Kg = e;
      this.config = p;
      this.ah = f;
      this.controlSize = g;
      this.Jg = this.Hg = this.Ai = !1;
      this.Fg = this.Eg = this.Lg = null;
      this.Mg = _.jl("mode");
      this.Ig = _.kl("mode");
      this.hp = k || null;
      this.Ig(1);
      this.Ai = m || !1;
      this.marker = new nNa(this.map);
      GLa(this, c, b);
      this.overlay = new _.gJa(h);
      h ||
        (this.overlay.bindTo("mapHeading", this),
        this.overlay.bindTo("tilt", this));
      this.overlay.bindTo("client", this);
      this.overlay.bindTo("client", a, "svClient");
      this.overlay.bindTo("streetViewControlOptions", a);
      this.offset = _.AJ(c, d);
    }
    Ql() {
      const a = this.map.overlayMapTypes,
        b = this.overlay;
      a.forEach((c, d) => {
        c == b && a.removeAt(d);
      });
      this.Hg = !1;
    }
    Vl() {
      const a = this.get("projection");
      a &&
        a.Fg &&
        (this.map.overlayMapTypes.push(this.overlay), (this.Hg = !0));
    }
    mode_changed() {
      const a = _.qJ(this.Mg());
      a != this.Hg && (a ? this.Vl() : this.Ql());
    }
    tilt_changed() {
      this.Hg && (this.Ql(), this.Vl());
    }
    heading_changed() {
      this.Hg && (this.Ql(), this.Vl());
    }
    result_changed() {
      const a = this.get("result"),
        b = a && a.location;
      this.set("position", b && b.latLng);
      this.set("description", b && b.shortDescription);
      this.set("panoId", b && b.pano);
      this.Jg
        ? this.Ig(1)
        : this.get("hover") || this.set("panoramaVisible", !!a);
    }
    panoramaVisible_changed() {
      this.Jg = this.get("panoramaVisible") == 0;
      const a = this.get("panoramaVisible"),
        b = this.get("hover");
      a || b || this.Ig(1);
      a && this.notify("position");
    }
  };
  var OLa = class extends _.Hk {
    constructor(a, b) {
      super();
      this.Yg = a;
      this.Eg = b;
      $L() ? HLa(a) : ((b = a), (a = _.HL(a)), IL(b));
      this.anchor = _.Is("a", a);
      $L()
        ? JKa(this.anchor, !0)
        : ((this.anchor.style.textDecoration = "none"),
          (this.anchor.style.color = "#fff"));
      this.anchor.setAttribute("target", "_new");
      a = ($L(), "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1");
      _.Es(a, this.anchor);
      this.anchor.setAttribute(
        "title",
        "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1 v\u1ec1 h\u00ecnh \u1ea3nh \u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1 v\u1edbi Google"
      );
      _.yk(this.anchor, "click", (c) => {
        const d = _.uE(c) ? 171380 : 171379;
        _.pl(window, _.uE(c) ? "Tdcmi" : "Tdcki");
        _.M(window, d);
      });
      _.Wn(
        this.anchor,
        "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1 v\u1ec1 h\u00ecnh \u1ea3nh \u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1 v\u1edbi Google"
      );
    }
    visible_changed() {
      const a = this.get("visible") !== !1 ? "" : "none";
      this.Yg.style.display = a;
      _.Ek(this.Yg, "resize");
    }
    takeDownUrl_changed() {
      var a = this.get("pov"),
        b = this.get("pano");
      const c = this.get("takeDownUrl");
      a &&
        (c || b) &&
        ((a =
          "1," +
          Number(Number(a.heading).toFixed(3)).toString() +
          ",," +
          Number(Number(Math.max(0, a.zoom - 1 || 0)).toFixed(3)).toString() +
          "," +
          Number(Number(-a.pitch).toFixed(3)).toString()),
        (b = c
          ? c + ("&cbp=" + a + "&hl=" + _.Mi.Eg().Eg())
          : this.Eg.getUrl("report", [
              "panoid=" + b,
              "cbp=" + a,
              "hl=" + _.Mi.Eg().Eg(),
            ])),
        _.Ar(this.anchor, _.MD(b)),
        this.set("rmiLinkData", {
          label: ($L(), "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1"),
          tooltip:
            "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1 v\u1ec1 h\u00ecnh \u1ea3nh \u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1 v\u1edbi Google",
          url: b,
        }));
    }
    pov_changed() {
      this.takeDownUrl_changed();
    }
    pano_changed() {
      this.takeDownUrl_changed();
    }
    Sq() {}
    Rq() {}
    Kj() {}
    Fl() {
      return this.Yg;
    }
  };
  var JMa = class extends _.Hk {
    constructor(a) {
      super();
      this.Ug = a.Ai ? 2 : 1;
      this.Tg = a.Ai ? !0 : !1;
      this.Rg = new _.Nm(() => {
        this.Pg[1] && sMa(this);
        this.Pg[0] && yMa(this);
        this.Pg[3] && VLa(this);
        this.Pg = {};
        this.get("disableDefaultUI") &&
          !this.Fg &&
          (_.pl(this.Eg, "Cdn"), _.M(this.Eg, 148245));
      }, 0);
      this.Hg = a.bE || null;
      this.Zg = a.Lp;
      this.Tg && IL(this.Zg);
      this.Vh = a.mv || null;
      this.Kg = a.controlSize;
      this.Fi = a.lH || null;
      this.Eg = a.map || null;
      this.Fg = a.oL || null;
      this.Ph = this.Eg || this.Fg;
      this.dj = a.fF;
      this.sj = a.nL || null;
      this.rj = a.ah || null;
      this.si = !!a.Ur;
      this.rk = !!a.gp;
      this.Pj = !!a.fp;
      this.tj = !!a.QH;
      this.cj = this.Wi = this.Zi = this.pj = !1;
      this.Ng = this.qj = this.nh = this.sh = null;
      this.Lg = a.Hr;
      this.Bi = _.eu(
        "Chuy\u1ec3n \u0111\u1ed5i ch\u1ebf \u0111\u1ed9 xem to\u00e0n m\u00e0n h\u00ecnh"
      );
      this.Vg = null;
      this.sk = a.Ck;
      this.Ig = this.Qg = null;
      this.fi = !1;
      this.Ih = [];
      this.Xg = null;
      this.tk = {};
      this.Pg = {};
      this.Wg = this.lh = this.gh = this.Ah = null;
      this.di = _.eu(
        "K\u00e9o Ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o v\u00e0o b\u1ea3n \u0111\u1ed3 \u0111\u1ec3 m\u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1"
      );
      this.Og = null;
      this.Jh = !1;
      _.ux(JLa, this.Lg);
      const b = (this.pi = new kNa());
      b.bindTo("center", this);
      b.bindTo("zoom", this);
      b.bindTo("mapTypeId", this);
      b.bindTo("pano", this);
      b.bindTo("position", this);
      b.bindTo("pov", this);
      b.bindTo("heading", this);
      b.bindTo("tilt", this);
      a.map &&
        _.sk(b, "url_changed", () => {
          a.map.set("mapUrl", b.get("url"));
        });
      const c = new lNa();
      c.bindTo("center", this);
      c.bindTo("zoom", this);
      c.bindTo("mapTypeId", this);
      c.bindTo("pano", this);
      c.bindTo("heading", this);
      this.Gk = c;
      KLa(this);
      this.Mg = NLa(this);
      this.Sg = null;
      PLa(this);
      this.dh = null;
      RLa(this);
      this.Jg = null;
      a.XE && TLa(this);
      VLa(this);
      WLa(this, a.UC);
      YLa(this);
      this.tl = $La(this);
      this.keyboardShortcuts_changed();
      _.an[35] && bMa(this);
      dMa(this);
    }
    bounds_changed() {
      this.Ig?.Sg(
        this.get("zoom"),
        this.get("zoomRange"),
        this.get("bounds"),
        this.get("restriction")
      );
    }
    restriction_changed() {
      this.Ig?.Sg(
        this.get("zoom"),
        this.get("zoomRange"),
        this.get("bounds"),
        this.get("restriction")
      );
    }
    disableDefaultUI_changed() {
      zMa(this);
    }
    size_changed() {
      zMa(this);
      this.get("size") &&
        (this.tl.update(this.get("size").width - (this.get("logoWidth") || 0)),
        this.Ig?.Rg(this.get("cameraControl"), this.get("size")));
    }
    mapTypeId_changed() {
      cM(this) != this.fi && ((this.Pg[1] = !0), _.Om(this.Rg));
      this.Wg && this.Wg.setMapTypeId(this.get("mapTypeId"));
      this.Ig?.Tg(this.get("mapTypeId"));
    }
    mapTypeControl_changed() {
      this.Pg[0] = !0;
      _.Om(this.Rg);
    }
    mapTypeControlOptions_changed() {
      this.Pg[0] = !0;
      _.Om(this.Rg);
    }
    fullscreenControlOptions_changed() {
      this.Pg[3] = !0;
      _.Om(this.Rg);
    }
    scaleControl_changed() {
      aM(this);
    }
    scaleControlOptions_changed() {
      aM(this);
    }
    keyboardShortcuts_changed() {
      const a = !!((this.Eg && _.hr(this.Eg)) || this.Fg);
      a
        ? ((this.sh.Yg.style.display = ""),
          this.Mg.set("keyboardShortcutsShown", !0))
        : a ||
          ((this.sh.Yg.style.display = "none"),
          this.Mg.set("keyboardShortcutsShown", !1));
    }
    cameraControl_changed() {
      bM(this);
    }
    cameraControlOptions_changed() {
      bM(this);
    }
    panControl_changed() {
      bM(this);
    }
    panControlOptions_changed() {
      bM(this);
    }
    rotateControl_changed() {
      bM(this);
    }
    rotateControlOptions_changed() {
      bM(this);
    }
    streetViewControl_changed() {
      bM(this);
    }
    streetViewControlOptions_changed() {
      bM(this);
    }
    zoomControl_changed() {
      bM(this);
    }
    zoomControlOptions_changed() {
      bM(this);
    }
    myLocationControl_changed() {
      bM(this);
    }
    myLocationControlOptions_changed() {
      bM(this);
    }
    streetView_changed() {
      GMa(this);
    }
    lj(a) {
      this.get("panoramaVisible") != a && this.set("panoramaVisible", a);
    }
    panoramaVisible_changed() {
      const a = this.get("streetView");
      a &&
        (this.Og && a.__gm.bindTo("sloTrackingId", this.Og),
        a.Eg.set(!!this.get("panoramaVisible")));
    }
  };
  var HMa = (0,
  _.Tf)`.dismissButton{background-color:#fff;border:1px solid #dadce0;color:#1a73e8;border-radius:4px;font-family:Roboto,sans-serif;font-size:14px;height:36px;cursor:pointer;padding:0 24px}.dismissButton:hover{background-color:rgba(66,133,244,.04);border:1px solid #d2e3fc}.dismissButton:focus{background-color:rgba(66,133,244,.12);border:1px solid #d2e3fc;outline:0}.dismissButton:focus:not(:focus-visible){background-color:#fff;border:1px solid #dadce0;outline:none}.dismissButton:focus-visible{background-color:rgba(66,133,244,.12);border:1px solid #d2e3fc;outline:0}.dismissButton:hover:focus{background-color:rgba(66,133,244,.16);border:1px solid #d2e2fd}.dismissButton:hover:focus:not(:focus-visible){background-color:rgba(66,133,244,.04);border:1px solid #d2e3fc}.dismissButton:hover:focus-visible{background-color:rgba(66,133,244,.16);border:1px solid #d2e2fd}.dismissButton:active{background-color:rgba(66,133,244,.16);border:1px solid #d2e2fd;-webkit-box-shadow:0 1px 2px 0 rgba(60,64,67,.3),0 1px 3px 1px rgba(60,64,67,.15);box-shadow:0 1px 2px 0 rgba(60,64,67,.3),0 1px 3px 1px rgba(60,64,67,.15)}.dismissButton:disabled{background-color:#fff;border:1px solid #f1f3f4;color:#3c4043}sentinel{}\n`;
  var oNa = [37, 38, 39, 40],
    pNa = [38, 40],
    qNa = [37, 39],
    rNa = { 38: [0, -1], 40: [0, 1], 37: [-1, 0], 39: [1, 0] },
    sNa = { 38: [0, 1], 40: [0, -1], 37: [-1, 0], 39: [1, 0] };
  var kM = Object.freeze([...pNa, ...qNa]),
    PMa = class extends _.Hk {
      constructor(a, b, c) {
        super();
        this.src = a;
        this.Sg = b;
        this.Rg = c;
        this.Hg = this.Fg = 0;
        this.Ig = null;
        this.Og = this.Eg = 0;
        this.Lg = this.Jg = null;
        this.Kg = {};
        this.Mg = {};
        _.hs(a, "keydown", this, this.Ug);
        _.hs(a, "keypress", this, this.Tg);
        _.hs(a, "keyup", this, this.Vg);
      }
      Ug(a) {
        if (OMa(this, a)) return !0;
        var b = !1;
        switch (a.keyCode) {
          case 38:
          case 40:
          case 37:
          case 39:
            b = a.shiftKey && pNa.indexOf(a.keyCode) >= 0;
            const c =
              a.shiftKey && qNa.indexOf(a.keyCode) >= 0 && this.Rg && !this.Fg;
            (b && this.Sg && !this.Fg) || c
              ? ((this.Mg[a.keyCode] = !0),
                this.Hg || ((this.Og = 0), (this.Eg = 1), this.Pg()),
                eM(b ? 165376 : 165375, b ? "Tmki" : "Rmki"))
              : this.Hg ||
                ((this.Kg[a.keyCode] = !0),
                this.Fg || ((this.Ig = new _.sJ(100)), this.Ng()),
                eM(165373, "Pmki"));
            b = !0;
            break;
          case 34:
            fM(this, 0, 0.75);
            b = !0;
            break;
          case 33:
            fM(this, 0, -0.75);
            b = !0;
            break;
          case 36:
            fM(this, -0.75, 0);
            b = !0;
            break;
          case 35:
            fM(this, 0.75, 0);
            b = !0;
            break;
          case 187:
          case 107:
            MMa(this);
            b = !0;
            break;
          case 189:
          case 109:
            NMa(this), (b = !0);
        }
        switch (a.which) {
          case 61:
          case 43:
            MMa(this);
            b = !0;
            break;
          case 45:
          case 95:
          case 173:
            NMa(this), (b = !0);
        }
        b && (_.pk(a), _.qk(a));
        return !b;
      }
      Tg(a) {
        if (OMa(this, a)) return !0;
        switch (a.keyCode) {
          case 38:
          case 40:
          case 37:
          case 39:
          case 34:
          case 33:
          case 36:
          case 35:
          case 187:
          case 107:
          case 189:
          case 109:
            return _.pk(a), _.qk(a), !1;
        }
        switch (a.which) {
          case 61:
          case 43:
          case 45:
          case 95:
          case 173:
            return _.pk(a), _.qk(a), !1;
        }
        return !0;
      }
      Vg(a) {
        let b = !1;
        switch (a.keyCode) {
          case 38:
          case 40:
          case 37:
          case 39:
            (this.Kg[a.keyCode] = null), (this.Mg[a.keyCode] = !1), (b = !0);
        }
        return !b;
      }
      Ng() {
        let a = 0,
          b = 0;
        var c = !1;
        for (var d of oNa)
          if (this.Kg[d]) {
            const [e, f] = rNa[d];
            c = f;
            a += e;
            b += c;
            c = !0;
          }
        c
          ? ((c = 1),
            _.rJ(this.Ig) && (c = this.Ig.next()),
            (d = Math.round(7 * c * 5 * a)),
            (c = Math.round(7 * c * 5 * b)),
            d === 0 && (d = a),
            c === 0 && (c = b),
            _.Ek(this, "panbynow", d, c, 1),
            (this.Fg = _.iE(this, this.Ng, 10)))
          : (this.Fg = 0);
      }
      Pg() {
        let a = 0,
          b = 0;
        var c = !1;
        for (let d = 0; d < kM.length; d++)
          this.Mg[kM[d]] &&
            ((c = sNa[kM[d]]), (a += c[0]), (b += c[1]), (c = !0));
        c
          ? (_.Ek(this, "tiltrotatebynow", this.Eg * a, this.Eg * b),
            (this.Hg = _.iE(this, this.Pg, 10)),
            (this.Eg = Math.min(1.8, this.Eg + 0.01)),
            this.Og++,
            (this.Jg = { x: a, y: b }))
          : ((this.Hg = 0),
            (this.Lg = new _.sJ(Math.min(Math.round(this.Og / 2), 35), 1)),
            _.iE(this, this.Qg, 10));
      }
      Qg() {
        if (!this.Hg && !this.Fg && _.rJ(this.Lg)) {
          var a = this.Jg.x,
            b = this.Jg.y,
            c = this.Lg.next();
          _.Ek(this, "tiltrotatebynow", this.Eg * c * a, this.Eg * c * b);
          _.iE(this, this.Qg, 10);
        }
      }
    };
  var tNa = class {
    constructor() {
      this.jC = $Ma;
      this.xJ = KMa;
      this.zJ = LMa;
      this.yJ = RMa;
    }
    WE(a, b) {
      a = _.IMa(a, b).style;
      a.border = "1px solid rgba(0,0,0,0.12)";
      a.borderRadius = "5px";
      a.left = "50%";
      a.maxWidth = "375px";
      a.msTransform = "translateX(-50%)";
      a.position = "absolute";
      a.transform = "translateX(-50%)";
      a.width = "calc(100% - 10px)";
      a.zIndex = "1";
    }
    CB(a) {
      if (_.Eda() && !a.__gm_bbsp) {
        a.__gm_bbsp = !0;
        var b = new _.Gr(
          "https://developers.google.com/maps/documentation/javascript/error-messages#unsupported-browsers"
        );
        new rKa(a, b);
      }
    }
  };
  _.kj("controls", new tNa());
});
